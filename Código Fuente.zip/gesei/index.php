<?php
include('bd.php');

if ($_REQUEST['entrar']) {
	$username = $_REQUEST['username'];
	$password = $_REQUEST['password'];
	$sql = mysql_query("SELECT * FROM abp_persona WHERE dni='$username' AND contrasena='$password'", $conexion);
	if (mysql_num_rows($sql) == 1) {
		$sqlCheck = mysql_query("SELECT * FROM abp_alumno WHERE dniPersona='$username'", $conexion);
		if (mysql_num_rows($sqlCheck) == 1) {
			$_SESSION['tipoPersona'] = 'Alumno';
		}
		else {
			$sqlCheck = mysql_query("SELECT * FROM abp_profesor WHERE dniPersona='$username'", $conexion);
			if (mysql_num_rows($sqlCheck) == 1) {
				$_SESSION['tipoPersona'] = 'Profesor';
			}
			else {
				$sqlCheck = mysql_query("SELECT * FROM abp_secretaria WHERE dniPersona='$username'", $conexion);
				if (mysql_num_rows($sqlCheck) == 1) {
					$_SESSION['tipoPersona'] = 'Secretar�a';
				}
				else {
					$sqlCheck = mysql_query("SELECT * FROM abp_becario WHERE dniPersona='$username'", $conexion);
					if (mysql_num_rows($sqlCheck) == 1) {
						$_SESSION['tipoPersona'] = 'Becario';
					}
					else {
						$sqlCheck = mysql_query("SELECT * FROM abp_direccion WHERE dniPersona='$username'", $conexion);
						if (mysql_num_rows($sqlCheck) == 1) {
							$_SESSION['tipoPersona'] = 'Director';
						}
						else {
							$_SESSION['tipoPersona'] = 'Error';
						}
					}
				}
			}
		}
		$_SESSION['persona'] = $_REQUEST['username'];
		$_SESSION['mensaje'] = 'Se ha iniciado la sesi�n';
		header('Location: firmas.php');
		die();
	}
	else {
		$_SESSION['mensaje'] = 'Los datos son incorrectos';
		header('Location: index.php');
		die();
	}
}
else {
	if ($_REQUEST['salir']) {
		session_destroy();
		header('Location: index.php');
		die();
	}
}

$titulo = 'Inicio';
include('cabecera.php');

if ($persona) {
	echo 'Sesi�n iniciada con '.$persona.' de tipo '.$tipoPersona;
	?>
	<form class="form-log" action="index.php" method="post">
		<input type="submit" name="salir" value="Salir">
	</form>
	<?php
}
else {
	?>
	<form class="form-log" action="index.php" method="post">
		<input type="text" name="username" placeholder="Usuario" required="required"><br>
		<input type="password" name="password" placeholder="Contrase�a" required="required"><br>
		<input type="submit" name="entrar" value="Entrar">
	</form>
	<?php
}

include('pie.php');
?>