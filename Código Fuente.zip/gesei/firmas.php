<?php
include('bd.php');

if ($_REQUEST['registrar']) {
	switch ($tipoPersona) {
		case 'Alumno':
			$idAAC = $_REQUEST['idAAC'];
			$idClase = $_REQUEST['idClase'];
			
			$sql = mysql_query("SELECT * FROM abp_tarea WHERE id = '$idClase' AND horaInicio < '$time' AND horaInicio+duracion > '$timeReplaced' AND diaFechaRegular = '$dia' AND '$date' NOT IN (SELECT fecha FROM abp_festivo)", $conexion);
			$sqlYaRealizado = mysql_query("SELECT * FROM abp_firmaAlumnoClase WHERE idClase = '$idClase' AND fecha = '$date' AND idAlumno = '$persona'", $conexion);
			if ((mysql_num_rows($sql) != 0) && (mysql_num_rows($sqlYaRealizado) == 0)) {
				mysql_query("INSERT INTO abp_firmaAlumnoClase (idAAC, idAlumno, idClase, fecha, hora) VALUES ('$idAAC', '$persona', '$idClase', '$date', '$time')", $conexion);
				$_SESSION['mensaje'] = 'Se ha firmado la asistencia';
			}
			else {
				$_SESSION['mensaje'] = 'No se ha podido firmar la asistencia correctamente';
			}
			header('Location: firmas.php');
			die();
			break;
		case 'Profesor':
			$idAPC = $_REQUEST['idAPC'];
			$idAPT = $_REQUEST['idAPT'];
			$idClase = $_REQUEST['idClase'];
			$idTutoria = $_REQUEST['idTutoria'];
			
			$sql = mysql_query("SELECT * FROM abp_tarea WHERE (id = '$idClase' OR id = '$idTutoria') AND horaInicio < '$time' AND horaInicio+duracion > '$timeReplaced' AND diaFechaRegular = '$dia' AND '$date' NOT IN (SELECT fecha FROM abp_festivo)", $conexion);
			if (mysql_num_rows($sql) != 0) {
				if ($_REQUEST['idAPC']) {
					$sqlYaRealizado = mysql_query("SELECT * FROM abp_firmaProfesorClase WHERE idClase = '$idClase' AND fecha = '$date' AND idProfesor = '$persona'", $conexion);
					if (mysql_num_rows($sqlYaRealizado) == 0) {
						mysql_query("INSERT INTO abp_firmaProfesorClase (idAPC, idProfesor, idClase, fecha, hora) VALUES ('$idAPC', '$persona', '$idClase', '$date', '$time')", $conexion);
							$_SESSION['mensaje'] = 'Se ha firmado la asistencia';
						}
						else {
							$_SESSION['mensaje'] = 'No se ha podido firmar la asistencia correctamente';
					}
				}
				else {
					$sqlYaRealizado = mysql_query("SELECT * FROM abp_firmaProfesorTutoria WHERE idTutoria = '$idTutoria' AND fecha = '$date' AND idProfesor = '$persona'", $conexion);
					if (mysql_num_rows($sqlYaRealizado) == 0) {
						mysql_query("INSERT INTO abp_firmaProfesorTutoria (idAPT, idProfesor, idTutoria, fecha, hora) VALUES ('$idAPT', '$persona', '$idTutoria', '$date', '$time')", $conexion);
						$_SESSION['mensaje'] = 'Se ha firmado la asistencia';
					}
					else {
						$_SESSION['mensaje'] = 'No se ha podido firmar la asistencia correctamente';
					}
				}
			}
			header('Location: firmas.php');
			die();
			break;
		case 'Becario':
			$idABPT = $_REQUEST['idABPT'];
			$idPuestoTrabajo = $_REQUEST['idPuestoTrabajo'];
			
			$sql = mysql_query("SELECT * FROM abp_tarea WHERE id = '$idPuestoTrabajo' AND horaInicio < '$time' AND horaInicio+duracion > '$timeReplaced' AND diaFechaRegular = '$dia' AND '$date' NOT IN (SELECT fecha FROM abp_festivo)", $conexion);
			$sqlYaRealizado = mysql_query("SELECT * FROM abp_firmaBecarioPuestoTrabajo WHERE idPuestoTrabajo = '$idPuestoTrabajo' AND fecha = '$date' AND idBecario = '$persona'", $conexion);
			if ((mysql_num_rows($sql) != 0) && (mysql_num_rows($sqlYaRealizado) == 0)) {
				mysql_query("INSERT INTO abp_firmaBecarioPuestoTrabajo (idABPT, idBecario, idPuestoTrabajo, fecha, hora) VALUES ('$idABPT', '$persona', '$idPuestoTrabajo', '$date', '$time')", $conexion);
				$_SESSION['mensaje'] = 'Se ha firmado la asistencia';
			}
			else {
				$_SESSION['mensaje'] = 'No se ha podido firmar la asistencia correctamente';
			}
			header('Location: firmas.php');
			die();
			break;
	}
}

$titulo = 'Control de Asistencia';
include('cabecera.php');

switch ($tipoPersona) {
	case 'Alumno':
		echo '<h2>Firmar asistencia</h2>';
		
		// Faltan cambios puntuales
		$sql = mysql_query("SELECT * FROM abp_tarea WHERE id IN (SELECT idClase FROM abp_asignacionAlumnoClase WHERE idAlumno = '$persona') AND horaInicio < '$time' AND horaInicio+duracion > '$timeReplaced' AND diaFechaRegular = '$dia' AND '$date' NOT IN (SELECT fecha FROM abp_festivo)", $conexion);
		if (mysql_num_rows($sql) == 0) {
			echo '<p>En estos momentos no tienes asistencias que firmar</p><br />';
		}
		else {
			while ($recorrer = mysql_fetch_assoc($sql)) {
				$idTarea = $recorrer['id'];
				$idRecurso = $recorrer['idRecurso'];
				$asignatura = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_asignatura WHERE id IN (SELECT idAsignatura FROM abp_clase WHERE idTarea = '$idTarea')", $conexion));
				$recurso = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_recurso WHERE id = '$idRecurso'", $conexion));
				$sqlYaRealizado = mysql_query("SELECT * FROM abp_firmaAlumnoClase WHERE idClase = '$idTarea' AND fecha = '$date' AND idAlumno = '$persona'", $conexion);
				if (mysql_num_rows($sqlYaRealizado) != 0) {
					echo '<p>La asistencia ya est� firmada</p><br />';
				}
				else {
					$datosFirma = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_asignacionAlumnoClase WHERE idClase = '$idTarea' AND idAlumno = '$persona'", $conexion));
					echo '<p>Asistencia a clase de '.$asignatura['nombre'].' en '.$recurso['nombre'].' ('.$recurso['planta'].'� Planta) los '.$recorrer['diaFechaRegular'].' a las '.$recorrer['horaInicio'].' y una duraci�n de '.$recorrer['duracion'].'</p>';
					?>
					<div class="boton_firma">
						<a href="firmas.php?registrar=true&idAAC=<?php echo $datosFirma['id']; ?>&idClase=<?php echo $idTarea; ?>">Firma</a>
					</div>
					<?php
				}
			}
		}
		
		echo '<h2>Planificaci�n</h2>';
		
		$sql = mysql_query("SELECT * FROM abp_tarea WHERE id IN (SELECT idClase FROM abp_asignacionAlumnoClase WHERE idAlumno = '$persona')", $conexion);
		if (mysql_num_rows($sql) == 0) {
			echo '<p>No tienes asistencias en la pr�xima semana</p><br />';
		}
		else {
			?>
			<table>
				<tbody>
					<tr>
						<th>Asignatura</th>
						<th>Recurso</th>
						<th>D�a</th>
						<th>Hora</th>
						<th>Duraci�n</th>
					</tr>
			<?php
			$alt = false;
			while ($recorrer = mysql_fetch_assoc($sql)) {
				$idTarea = $recorrer['id'];
				$idRecurso = $recorrer['idRecurso'];
				$asignatura = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_asignatura WHERE id IN (SELECT idAsignatura FROM abp_clase WHERE idTarea = '$idTarea')", $conexion));
				$recurso = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_recurso WHERE id = '$idRecurso'", $conexion));
				if ($alt) { echo '<tr class="alt">'; $alt = false; } else { echo '<tr>'; $alt = true; }
					echo '<td>'.$asignatura['nombre'].'</td>';
					echo '<td>'.$recurso['nombre'].' ('.$recurso['planta'].'� Planta)</td>';
					echo '<td>'.$recorrer['diaFechaRegular'].'</td>';
					echo '<td>'.$recorrer['horaInicio'].'</td>';
					echo '<td>'.$recorrer['duracion'].'</td>';
				echo '</tr>';
			}
			?>
				</tbody>
			</table>
			<br />
			<?php
		}
		
		echo '<h2>�ltimas firmas</h2>';
		
		$sql = mysql_query("SELECT * FROM abp_firmaAlumnoClase WHERE idAlumno = '$persona'", $conexion);
		if (mysql_num_rows($sql) == 0) {
			echo '<p>No has realizado ninguna firma</p>';
		}
		else {
			?>
			<table>
				<tbody>
					<tr>
						<th>Fecha</th>
						<th>Hora</th>
						<th>Asignatura</th>
						<th>Recurso</th>
					</tr>
			<?php
			$alt = false;
			while ($recorrer = mysql_fetch_assoc($sql)) {
				$idTarea = $recorrer['idClase'];
				$asignatura = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_asignatura WHERE id IN (SELECT idAsignatura FROM abp_clase WHERE idTarea = '$idTarea')", $conexion));
				$recurso = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_recurso WHERE id IN (SELECT idRecurso FROM abp_tarea WHERE id = '$idTarea')", $conexion));
				if ($alt) { echo '<tr class="alt">'; $alt = false; } else { echo '<tr>'; $alt = true; }
					echo '<td>'.$recorrer['fecha'].'</td>';
					echo '<td>'.$recorrer['hora'].'</td>';
					echo '<td>'.$asignatura['nombre'].'</td>';
					echo '<td>'.$recurso['nombre'].' ('.$recurso['planta'].'� Planta)</td>';
				echo '</tr>';
			}
			?>
				</tbody>
			</table>
			<?php
		}
		break;
	case 'Profesor':
		echo '<h2>Firmar asistencia</h2>';
		
		// Faltan cambios puntuales
		$sql = mysql_query("SELECT * FROM abp_tarea WHERE (id IN (SELECT idClase FROM abp_asignacionProfesorClase WHERE idProfesor = '$persona') OR id IN (SELECT idTutoria FROM abp_asignacionProfesorTutoria WHERE idProfesor = '$persona')) AND horaInicio < '$time' AND horaInicio+duracion > '$timeReplaced' AND diaFechaRegular = '$dia' AND '$date' NOT IN (SELECT fecha FROM abp_festivo)", $conexion);
		if (mysql_num_rows($sql) == 0) {
			echo '<p>En estos momentos no tienes asistencias que firmar</p><br />';
		}
		else {
			while ($recorrer = mysql_fetch_assoc($sql)) {
				$idTarea = $recorrer['id'];
				$checkAsignacionC = mysql_query("SELECT * FROM abp_asignacionProfesorClase WHERE idClase = '$idTarea' AND idProfesor = '$persona'", $conexion);
				$checkAsignacionT = mysql_query("SELECT * FROM abp_asignacionProfesorTutoria WHERE idTutoria = '$idTarea' AND idProfesor = '$persona'", $conexion);
				if (mysql_num_rows($checkAsignacionC) == 1) {
					$idRecurso = $recorrer['idRecurso'];
					$asignatura = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_asignatura WHERE id IN (SELECT idAsignatura FROM abp_clase WHERE idTarea = '$idTarea')", $conexion));
					$recurso = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_recurso WHERE id = '$idRecurso'", $conexion));
					$sqlYaRealizado = mysql_query("SELECT * FROM abp_firmaProfesorClase WHERE idClase = '$idTarea' AND fecha = '$date' AND idProfesor = '$persona'", $conexion);
					if (mysql_num_rows($sqlYaRealizado) != 0) {
						echo '<p>La asistencia ya est� firmada</p><br />';
					}
					else {
						$assoc = mysql_fetch_assoc($checkAsignacionC);
						echo '<p>Docencia de '.$asignatura['nombre'].' en '.$recurso['nombre'].' ('.$recurso['planta'].'� Planta) los '.$recorrer['diaFechaRegular'].' a las '.$recorrer['horaInicio'].' y una duraci�n de '.$recorrer['duracion'].'</p>';
						?>
						<div class="boton_firma">
							<a href="firmas.php?registrar=true&idAPC=<?php echo $assoc['id']; ?>&idClase=<?php echo $idTarea; ?>">Firma</a>
						</div>
						<?php
					}
				}
				else {
					$idRecurso = $recorrer['idRecurso'];
					$recurso = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_recurso WHERE id = '$idRecurso'", $conexion));
					$sqlYaRealizado = mysql_query("SELECT * FROM abp_firmaProfesorTutoria WHERE idTutoria = '$idTarea' AND fecha = '$date' AND idProfesor = '$persona'", $conexion);
					if (mysql_num_rows($sqlYaRealizado) != 0) {
						echo '<p>La asistencia ya est� firmada</p><br />';
					}
					else {
						$assoc = mysql_fetch_assoc($checkAsignacionT);
						echo '<p>Tutoria en '.$recurso['nombre'].' ('.$recurso['planta'].'� Planta) los '.$recorrer['diaFechaRegular'].' a las '.$recorrer['horaInicio'].' y una duraci�n de '.$recorrer['duracion'].'</p>';
						?>
						<div class="boton_firma">
							<a href="firmas.php?registrar=true&idAPT=<?php echo $assoc['id']; ?>&idTutoria=<?php echo $idTarea; ?>">Firma</a>
						</div>
						<?php
					}
				}
			}
		}
		
		echo '<h2>Planificaci�n</h2>';
		
		$sql = mysql_query("SELECT * FROM abp_tarea WHERE (id IN (SELECT idClase FROM abp_asignacionProfesorClase WHERE idProfesor = '$persona') OR id IN (SELECT idTutoria FROM abp_asignacionProfesorTutoria WHERE idProfesor = '$persona'))", $conexion);
		if (mysql_num_rows($sql) == 0) {
			echo '<p>No tienes asistencias en la pr�xima semana</p><br />';
		}
		else {
			?>
			<table>
				<tbody>
					<tr>
						<th>Tarea</th>
						<th>Recurso</th>
						<th>D�a</th>
						<th>Hora</th>
						<th>Duraci�n</th>
					</tr>
			<?php
			$alt = false;
			while ($recorrer = mysql_fetch_assoc($sql)) {
				$idTarea = $recorrer['id'];
				$idRecurso = $recorrer['idRecurso'];
				$checkAsignacionC = mysql_query("SELECT * FROM abp_asignacionProfesorClase WHERE idClase = '$idTarea' AND idProfesor = '$persona'", $conexion);
				$checkAsignacionT = mysql_query("SELECT * FROM abp_asignacionProfesorTutoria WHERE idTutoria = '$idTarea' AND idProfesor = '$persona'", $conexion);
				if (mysql_num_rows($checkAsignacionC) == 1) {
					$asignatura = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_asignatura WHERE id IN (SELECT idAsignatura FROM abp_clase WHERE idTarea = '$idTarea')", $conexion));
					$asignatura = $asignatura['nombre'];
				}
				else {
					$asignatura = 'Tutor�a';
				}
				$recurso = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_recurso WHERE id = '$idRecurso'", $conexion));
				if ($alt) { echo '<tr class="alt">'; $alt = false; } else { echo '<tr>'; $alt = true; }
					echo '<td>'.$asignatura.'</td>';
					echo '<td>'.$recurso['nombre'].' ('.$recurso['planta'].'� Planta)</td>';
					echo '<td>'.$recorrer['diaFechaRegular'].'</td>';
					echo '<td>'.$recorrer['horaInicio'].'</td>';
					echo '<td>'.$recorrer['duracion'].'</td>';
				echo '</tr>';
			}
			?>
				</tbody>
			</table>
			<br />
			<?php
		}
		
		echo '<h2>�ltimas firmas</h2>';
		
		$sqlC = mysql_query("SELECT * FROM abp_firmaProfesorClase WHERE idProfesor = '$persona'", $conexion);
		$sqlT = mysql_query("SELECT * FROM abp_firmaProfesorTutoria WHERE idProfesor = '$persona'", $conexion);
		if ((mysql_num_rows($sqlC) == 0) && (mysql_num_rows($sqlT) == 0)) {
			echo '<p>No has realizado ninguna firma</p>';
		}
		else {
			?>
			<table>
				<tbody>
					<tr>
						<th>Fecha</th>
						<th>Hora</th>
						<th>Asignatura</th>
						<th>Recurso</th>
					</tr>
			<?php
			$alt = false;
			while ($recorrer = mysql_fetch_assoc($sqlC)) {
				$idTarea = $recorrer['idClase'];
				$asignatura = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_asignatura WHERE id IN (SELECT idAsignatura FROM abp_clase WHERE idTarea = '$idTarea')", $conexion));
				$recurso = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_recurso WHERE id IN (SELECT idRecurso FROM abp_tarea WHERE id = '$idTarea')", $conexion));
				if ($alt) { echo '<tr class="alt">'; $alt = false; } else { echo '<tr>'; $alt = true; }
					echo '<td>'.$recorrer['fecha'].'</td>';
					echo '<td>'.$recorrer['hora'].'</td>';
					echo '<td>'.$asignatura['nombre'].'</td>';
					echo '<td>'.$recurso['nombre'].' ('.$recurso['planta'].'� Planta)</td>';
				echo '</tr>';
			}
			while ($recorrer = mysql_fetch_assoc($sqlT)) {
				$idTarea = $recorrer['idTutoria'];
				$recurso = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_recurso WHERE id IN (SELECT idRecurso FROM abp_tarea WHERE id = '$idTarea')", $conexion));
				if ($alt) { echo '<tr class="alt">'; $alt = false; } else { echo '<tr>'; $alt = true; }
					echo '<td>'.$recorrer['fecha'].'</td>';
					echo '<td>'.$recorrer['hora'].'</td>';
					echo '<td>Tutor�a</td>';
					echo '<td>'.$recurso['nombre'].' ('.$recurso['planta'].'� Planta)</td>';
				echo '</tr>';
			}
			?>
				</tbody>
			</table>
			<?php
		}
		break;
	case 'Becario':
		echo '<h2>Firmar asistencia</h2>';
		
		// Faltan cambios puntuales
		$sql = mysql_query("SELECT * FROM abp_tarea WHERE id IN (SELECT idPuestoTrabajo FROM abp_asignacionBecarioPuestoTrabajo WHERE idBecario = '$persona') AND horaInicio < '$time' AND horaInicio+duracion > '$timeReplaced' AND diaFechaRegular = '$dia' AND '$date' NOT IN (SELECT fecha FROM abp_festivo)", $conexion);
		if (mysql_num_rows($sql) == 0) {
			echo '<p>En estos momentos no tienes asistencias que firmar</p><br />';
		}
		else {
			while ($recorrer = mysql_fetch_assoc($sql)) {
				$idTarea = $recorrer['id'];
				$idRecurso = $recorrer['idRecurso'];
				$recurso = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_recurso WHERE id = '$idRecurso'", $conexion));
				$sqlYaRealizado = mysql_query("SELECT * FROM abp_firmaBecarioPuestoTrabajo WHERE idPuestoTrabajo = '$idTarea' AND fecha = '$date' AND idBecario = '$persona'", $conexion);
				if (mysql_num_rows($sqlYaRealizado) != 0) {
					echo '<p>La asistencia ya est� firmada</p><br />';
				}
				else {
					$datosFirma = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_asignacionBecarioPuestoTrabajo WHERE idPuestoTrabajo = '$idTarea' AND idBecario = '$persona'", $conexion));
					echo '<p>Asistencia a puesto de trabajo en '.$recurso['nombre'].' ('.$recurso['planta'].'� Planta) los '.$recorrer['diaFechaRegular'].' a las '.$recorrer['horaInicio'].' y una duraci�n de '.$recorrer['duracion'].'</p>';
					?>
					<div class="boton_firma">
						<a href="firmas.php?registrar=true&idABPT=<?php echo $datosFirma['id']; ?>&idPuestoTrabajo=<?php echo $idTarea; ?>">Firma</a>
					</div>
					<?php
				}
			}
		}
		
		echo '<h2>Planificaci�n</h2>';
		
		$sql = mysql_query("SELECT * FROM abp_tarea WHERE id IN (SELECT idPuestoTrabajo FROM abp_asignacionBecarioPuestoTrabajo WHERE idBecario = '$persona')", $conexion);
		if (mysql_num_rows($sql) == 0) {
			echo '<p>No tienes asistencias en la pr�xima semana</p><br />';
		}
		else {
			?>
			<table>
				<tbody>
					<tr>
						<th>Recurso</th>
						<th>D�a</th>
						<th>Hora</th>
						<th>Duraci�n</th>
					</tr>
			<?php
			$alt = false;
			while ($recorrer = mysql_fetch_assoc($sql)) {
				$idTarea = $recorrer['id'];
				$idRecurso = $recorrer['idRecurso'];
				$recurso = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_recurso WHERE id = '$idRecurso'", $conexion));
				if ($alt) { echo '<tr class="alt">'; $alt = false; } else { echo '<tr>'; $alt = true; }
					echo '<td>'.$recurso['nombre'].' ('.$recurso['planta'].'� Planta)</td>';
					echo '<td>'.$recorrer['diaFechaRegular'].'</td>';
					echo '<td>'.$recorrer['horaInicio'].'</td>';
					echo '<td>'.$recorrer['duracion'].'</td>';
				echo '</tr>';
			}
			?>
				</tbody>
			</table>
			<br />
			<?php
		}
		
		echo '<h2>�ltimas firmas</h2>';
		
		$sql = mysql_query("SELECT * FROM abp_firmaBecarioPuestoTrabajo WHERE idBecario = '$persona'", $conexion);
		if (mysql_num_rows($sql) == 0) {
			echo '<p>No has realizado ninguna firma</p>';
		}
		else {
			?>
			<table>
				<tbody>
					<tr>
						<th>Fecha</th>
						<th>Hora</th>
						<th>Recurso</th>
					</tr>
			<?php
			$alt = false;
			while ($recorrer = mysql_fetch_assoc($sql)) {
				$idTarea = $recorrer['idPuestoTrabajo'];
				$recurso = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_recurso WHERE id IN (SELECT idRecurso FROM abp_tarea WHERE id = '$idTarea')", $conexion));
				if ($alt) { echo '<tr class="alt">'; $alt = false; } else { echo '<tr>'; $alt = true; }
					echo '<td>'.$recorrer['fecha'].'</td>';
					echo '<td>'.$recorrer['hora'].'</td>';
					echo '<td>'.$recurso['nombre'].' ('.$recurso['planta'].'� Planta)</td>';
				echo '</tr>';
			}
			?>
				</tbody>
			</table>
			<?php
		}
		break;
	default:
		echo '<p>No tienes permisos para esta secci�n</p>';
		break;
}

include('pie.php');
?>