-- phpMyAdmin SQL Dump
-- version OVH
-- http://www.phpmyadmin.net
--
-- Servidor: mysql51-63.perso
-- Tiempo de generación: 15-12-2012 a las 17:07:21
-- Versión del servidor: 5.1.49
-- Versión de PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `mynubredatos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_alumno`
--

CREATE TABLE IF NOT EXISTS `abp_alumno` (
  `dniPersona` varchar(9) NOT NULL,
  PRIMARY KEY (`dniPersona`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `abp_alumno`
--

INSERT INTO `abp_alumno` (`dniPersona`) VALUES
('44464087G'),
('47048169J');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_asignacionAlumnoClase`
--

CREATE TABLE IF NOT EXISTS `abp_asignacionAlumnoClase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idAlumno` varchar(9) NOT NULL,
  `idClase` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `abp_asignacionAlumnoClase`
--

INSERT INTO `abp_asignacionAlumnoClase` (`id`, `idAlumno`, `idClase`) VALUES
(1, '44464087G', 1),
(2, '44464087G', 2),
(3, '47048169J', 2),
(7, '47048169J', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_asignacionBecarioPuestoTrabajo`
--

CREATE TABLE IF NOT EXISTS `abp_asignacionBecarioPuestoTrabajo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idBecario` varchar(9) NOT NULL,
  `idPuestoTrabajo` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `abp_asignacionBecarioPuestoTrabajo`
--

INSERT INTO `abp_asignacionBecarioPuestoTrabajo` (`id`, `idBecario`, `idPuestoTrabajo`) VALUES
(1, '88888888Y', 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_asignacionProfesorClase`
--

CREATE TABLE IF NOT EXISTS `abp_asignacionProfesorClase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idProfesor` varchar(9) NOT NULL,
  `idClase` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `abp_asignacionProfesorClase`
--

INSERT INTO `abp_asignacionProfesorClase` (`id`, `idProfesor`, `idClase`) VALUES
(1, '12345678A', 1),
(2, '87654321Z', 2),
(3, '12345678A', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_asignacionProfesorTutoria`
--

CREATE TABLE IF NOT EXISTS `abp_asignacionProfesorTutoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idProfesor` varchar(9) NOT NULL,
  `idTutoria` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `abp_asignacionProfesorTutoria`
--

INSERT INTO `abp_asignacionProfesorTutoria` (`id`, `idProfesor`, `idTutoria`) VALUES
(1, '12345678A', 4),
(2, '87654321Z', 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_asignatura`
--

CREATE TABLE IF NOT EXISTS `abp_asignatura` (
  `id` varchar(5) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `abp_asignatura`
--

INSERT INTO `abp_asignatura` (`id`, `nombre`) VALUES
('ABP', 'Aprendizaxe Baseado en Proxectos'),
('DGP', 'Dirección e Xestión de Proxectos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_becario`
--

CREATE TABLE IF NOT EXISTS `abp_becario` (
  `dniPersona` varchar(9) NOT NULL,
  `salario` float NOT NULL,
  PRIMARY KEY (`dniPersona`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `abp_becario`
--

INSERT INTO `abp_becario` (`dniPersona`, `salario`) VALUES
('88888888Y', 2000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_cambioPuntual`
--

CREATE TABLE IF NOT EXISTS `abp_cambioPuntual` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fechaOriginal` datetime NOT NULL,
  `fechaNueva` datetime NOT NULL,
  `motivo` varchar(100) NOT NULL,
  `idTarea` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_clase`
--

CREATE TABLE IF NOT EXISTS `abp_clase` (
  `idTarea` int(11) NOT NULL,
  `idAsignatura` varchar(5) NOT NULL,
  PRIMARY KEY (`idTarea`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `abp_clase`
--

INSERT INTO `abp_clase` (`idTarea`, `idAsignatura`) VALUES
(1, 'ABP'),
(2, 'DGP'),
(3, 'ABP');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_direccion`
--

CREATE TABLE IF NOT EXISTS `abp_direccion` (
  `dniPersona` varchar(9) NOT NULL,
  PRIMARY KEY (`dniPersona`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `abp_direccion`
--

INSERT INTO `abp_direccion` (`dniPersona`) VALUES
('11111111B');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_fechaRegular`
--

CREATE TABLE IF NOT EXISTS `abp_fechaRegular` (
  `dia` varchar(10) NOT NULL,
  PRIMARY KEY (`dia`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `abp_fechaRegular`
--

INSERT INTO `abp_fechaRegular` (`dia`) VALUES
('Jueves'),
('Lunes'),
('Martes'),
('Miércoles'),
('Viernes');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_festivo`
--

CREATE TABLE IF NOT EXISTS `abp_festivo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `diaFechaRegular` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `abp_festivo`
--

INSERT INTO `abp_festivo` (`id`, `fecha`, `nombre`, `diaFechaRegular`) VALUES
(1, '2012-12-06', 'Día de la Constitución', 'Jueves');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_firmaAlumnoClase`
--

CREATE TABLE IF NOT EXISTS `abp_firmaAlumnoClase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idAAC` int(11) NOT NULL,
  `idAlumno` varchar(9) NOT NULL,
  `idClase` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Volcado de datos para la tabla `abp_firmaAlumnoClase`
--

INSERT INTO `abp_firmaAlumnoClase` (`id`, `idAAC`, `idAlumno`, `idClase`, `fecha`, `hora`) VALUES
(21, 3, '47048169J', 2, '2012-11-28', '11:00:00'),
(23, 1, '44464087G', 1, '2012-11-26', '16:30:00'),
(24, 2, '44464087G', 2, '2012-11-28', '11:00:00'),
(25, 7, '47048169J', 1, '2012-12-03', '16:30:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_firmaBecarioPuestoTrabajo`
--

CREATE TABLE IF NOT EXISTS `abp_firmaBecarioPuestoTrabajo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idABPT` int(11) NOT NULL,
  `idBecario` varchar(9) NOT NULL,
  `idPuestoTrabajo` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `abp_firmaBecarioPuestoTrabajo`
--

INSERT INTO `abp_firmaBecarioPuestoTrabajo` (`id`, `idABPT`, `idBecario`, `idPuestoTrabajo`, `fecha`, `hora`) VALUES
(1, 1, '88888888Y', 6, '2012-11-26', '16:30:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_firmaProfesorClase`
--

CREATE TABLE IF NOT EXISTS `abp_firmaProfesorClase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idAPC` int(11) NOT NULL,
  `idProfesor` varchar(9) NOT NULL,
  `idClase` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Volcado de datos para la tabla `abp_firmaProfesorClase`
--

INSERT INTO `abp_firmaProfesorClase` (`id`, `idAPC`, `idProfesor`, `idClase`, `fecha`, `hora`) VALUES
(10, 1, '12345678A', 1, '2012-11-26', '16:30:00'),
(11, 3, '12345678A', 3, '2012-11-26', '18:00:00'),
(12, 2, '87654321Z', 2, '2012-11-28', '11:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_firmaProfesorTutoria`
--

CREATE TABLE IF NOT EXISTS `abp_firmaProfesorTutoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idAPT` int(11) NOT NULL,
  `idProfesor` varchar(9) NOT NULL,
  `idTutoria` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `abp_firmaProfesorTutoria`
--

INSERT INTO `abp_firmaProfesorTutoria` (`id`, `idAPT`, `idProfesor`, `idTutoria`, `fecha`, `hora`) VALUES
(7, 1, '12345678A', 4, '2012-11-27', '10:30:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_incidencia`
--

CREATE TABLE IF NOT EXISTS `abp_incidencia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idPersona` varchar(9) NOT NULL,
  `idTarea` int(11) NOT NULL,
  `tipoTarea` int(1) NOT NULL,
  `idAsignacion` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `nivel` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `abp_incidencia`
--

INSERT INTO `abp_incidencia` (`id`, `idPersona`, `idTarea`, `tipoTarea`, `idAsignacion`, `fecha`, `nivel`) VALUES
(4, '47048169J', 1, 1, 7, '2012-11-26', 0),
(5, '87654321Z', 5, 4, 2, '2012-11-27', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_persona`
--

CREATE TABLE IF NOT EXISTS `abp_persona` (
  `dni` varchar(9) NOT NULL,
  `contrasena` varchar(50) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellidos` varchar(200) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefono` int(11) NOT NULL,
  `direccion` varchar(100) NOT NULL,
  PRIMARY KEY (`dni`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `abp_persona`
--

INSERT INTO `abp_persona` (`dni`, `contrasena`, `nombre`, `apellidos`, `email`, `telefono`, `direccion`) VALUES
('11111111B', '11111111B', 'Enrique', 'Barreiro Alonso', 'direccion@esei.uvigo.es', 988555555, 'Despacho do Director'),
('12345678A', '12345678A', 'Pedro', 'Cuesta Morales', 'pcuestam@gmail.com', 677456456, 'Rúa da Universidade 10 1ºA'),
('44464087G', '44464087G', 'Alexandre', 'Ramilo Conde', 'arconde@esei.uvigo.es', 677123123, 'Rúa Río Mao 30 2ºA'),
('47048169J', '47048169J', 'Pablo', 'Prol Sobrado', 'ppsobrado@esei.uvigo.es', 62201105, 'Rúa Rincon 10 Bajo B'),
('87654321Z', '87654321Z', 'Celso', 'Campos Basto', 'ccampos@uvigo.es', 677789789, 'Rúa da Universidade 10 2ºA'),
('88888888Y', '88888888Y', 'Becario', 'Martínez Pérez', 'becarios@infraestructura.ei.uvigo.es', 988789789, 'Laboratorio 409');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_profesor`
--

CREATE TABLE IF NOT EXISTS `abp_profesor` (
  `dniPersona` varchar(9) NOT NULL,
  `salario` float NOT NULL,
  `nivel` varchar(50) NOT NULL,
  PRIMARY KEY (`dniPersona`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `abp_profesor`
--

INSERT INTO `abp_profesor` (`dniPersona`, `salario`, `nivel`) VALUES
('12345678A', 2000, 'Docente Investigador'),
('87654321Z', 3000, 'Docente Investigador');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_puestoTrabajo`
--

CREATE TABLE IF NOT EXISTS `abp_puestoTrabajo` (
  `idTarea` int(11) NOT NULL,
  `idBecario` varchar(9) NOT NULL,
  PRIMARY KEY (`idTarea`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `abp_puestoTrabajo`
--

INSERT INTO `abp_puestoTrabajo` (`idTarea`, `idBecario`) VALUES
(6, '88888888Y');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_recurso`
--

CREATE TABLE IF NOT EXISTS `abp_recurso` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `planta` int(1) NOT NULL,
  `numero` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Volcado de datos para la tabla `abp_recurso`
--

INSERT INTO `abp_recurso` (`id`, `nombre`, `planta`, `numero`) VALUES
(1, 'Aula 3.1', 3, 1),
(2, 'Aula 2.2', 2, 2),
(3, 'Laboratorio 38', 3, 18),
(4, 'Despacho 411', 4, 11),
(5, 'Despacho 410', 4, 10),
(6, 'Infraestructura', -1, 9);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_secretaria`
--

CREATE TABLE IF NOT EXISTS `abp_secretaria` (
  `dniPersona` varchar(9) NOT NULL,
  PRIMARY KEY (`dniPersona`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_tarea`
--

CREATE TABLE IF NOT EXISTS `abp_tarea` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `horaInicio` time NOT NULL,
  `duracion` time NOT NULL,
  `diaFechaRegular` varchar(10) NOT NULL,
  `idRecurso` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Volcado de datos para la tabla `abp_tarea`
--

INSERT INTO `abp_tarea` (`id`, `horaInicio`, `duracion`, `diaFechaRegular`, `idRecurso`) VALUES
(1, '16:00:00', '01:30:00', 'Lunes', 1),
(2, '10:30:00', '01:30:00', 'Miércoles', 2),
(3, '17:30:00', '02:00:00', 'Lunes', 3),
(4, '10:00:00', '02:00:00', 'Martes', 4),
(5, '09:00:00', '01:30:00', 'Martes', 5),
(6, '16:00:00', '01:30:00', 'Lunes', 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abp_tutoria`
--

CREATE TABLE IF NOT EXISTS `abp_tutoria` (
  `idTarea` int(11) NOT NULL,
  `idProfesor` varchar(9) NOT NULL,
  PRIMARY KEY (`idTarea`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `abp_tutoria`
--

INSERT INTO `abp_tutoria` (`idTarea`, `idProfesor`) VALUES
(4, '12345678A'),
(5, '87654321Z');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `archivo`
--

CREATE TABLE IF NOT EXISTS `archivo` (
  `idArchivo` int(10) NOT NULL,
  `idRelacion` int(10) DEFAULT NULL,
  `tipoRelacion` int(1) DEFAULT NULL,
  `idAsignatura` varchar(6) DEFAULT NULL,
  `curso` int(4) DEFAULT NULL,
  `descripcion` varchar(1000) DEFAULT NULL,
  `nombreUsuario` varchar(50) NOT NULL,
  `fechaSubida` datetime NOT NULL,
  `enlace` varchar(500) NOT NULL,
  PRIMARY KEY (`idArchivo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `archivo`
--

INSERT INTO `archivo` (`idArchivo`, `idRelacion`, `tipoRelacion`, `idAsignatura`, `curso`, `descripcion`, `nombreUsuario`, `fechaSubida`, `enlace`) VALUES
(3, NULL, 5, 'AC II', NULL, 'El Puerto Serie RS232', 'prolsobrado', '2011-08-31 09:59:18', 'http://atc.ugr.es/docencia/udigital/1209.html'),
(4, NULL, 5, 'AC II', NULL, 'Interrupciones en el 80x86', 'prolsobrado', '2011-08-31 09:59:44', 'http://atc.ugr.es/docencia/udigital/1204.html'),
(5, NULL, 5, 'AC II', NULL, 'Lista de Interrupciones', 'prolsobrado', '2011-08-31 10:00:15', 'http://www.terra.es/personal/guillet/curso2.htm'),
(7, NULL, 5, 'AED II', NULL, 'Simulador Árboles', 'prolsobrado', '2011-09-03 10:46:08', 'http://people.ksp.sk/~kuko/bak/'),
(8, NULL, 5, 'AED II', NULL, 'Descargar BlueJ', 'prolsobrado', '2011-09-03 10:46:35', 'http://www.bluej.org/download/download.html'),
(9, NULL, 5, 'AED I', NULL, 'Descargar BlueJ', 'prolsobrado', '2011-09-03 10:46:59', 'http://www.bluej.org/download/download.html'),
(10, NULL, 5, 'IS I', NULL, 'Gantter', 'prolsobrado', '2011-09-03 10:47:39', 'https://app.gantter.com/'),
(11, NULL, 5, 'RC I', NULL, 'NetAcad', 'prolsobrado', '2011-09-03 10:49:02', 'https://auth.netacad.net/idp/Authn/NetacadLogin'),
(12, NULL, 5, 'SO II', NULL, 'Wiki SO II', 'prolsobrado', '2011-09-03 10:52:12', 'http://so2.atopa.me/wiki/index.php/P%C3%A1gina_Principal'),
(13, NULL, 5, 'ATE', NULL, 'Podcast Tema 1', 'prolsobrado', '2011-09-03 11:16:12', 'http://vimeo.com/19302989'),
(14, NULL, 5, 'ATE', NULL, 'Podcast Tema 2', 'prolsobrado', '2011-09-03 11:16:28', 'http://vimeo.com/19997243'),
(15, NULL, 5, 'EST', NULL, 'Medidas Descriptivas', 'prolsobrado', '2011-09-03 11:19:42', 'http://www.bioestadistica.uma.es/libro/node12.htm'),
(16, NULL, 5, 'EST', NULL, 'Medidas Descriptivas', 'prolsobrado', '2011-09-03 11:20:02', 'http://www.tuveras.com/estadistica/estadistica02.htm'),
(17, NULL, 5, 'EST', NULL, 'Fórmulas de Estadística', 'prolsobrado', '2011-09-03 11:20:19', 'http://www.vitutor.net/1/estadistica.html'),
(18, NULL, 5, 'EST', NULL, 'Manual de R para principiantes', 'prolsobrado', '2011-09-03 11:20:44', 'http://cran.r-project.org/doc/contrib/rdebuts_es.pdf'),
(19, NULL, 5, 'EST', NULL, 'Wiki EST', 'prolsobrado', '2011-09-03 11:26:07', 'http://exei.wikispaces.com/EST'),
(20, NULL, 5, 'AL', NULL, 'Descargar Maxima', 'prolsobrado', '2011-09-03 11:38:52', 'http://sourceforge.net/projects/maxima/files/'),
(21, NULL, 5, 'FMI', NULL, 'Descargar Maxima', 'prolsobrado', '2011-09-03 11:39:47', 'http://sourceforge.net/projects/maxima/files/'),
(22, NULL, 5, 'PRO I', NULL, 'Descargar Codeblocks', 'prolsobrado', '2011-09-03 11:40:13', 'http://www.codeblocks.org/downloads'),
(23, NULL, 5, 'PRO II', NULL, 'Descargar Codeblocks', 'prolsobrado', '2011-09-03 11:40:27', 'http://www.codeblocks.org/downloads'),
(24, NULL, 5, 'EST', NULL, 'Descargar R', 'prolsobrado', '2011-09-03 11:44:31', 'http://cran.es.r-project.org/'),
(25, NULL, 5, 'IS I', NULL, 'Descargar Visual Paradigm', 'prolsobrado', '2011-09-03 11:45:34', 'http://www.visual-paradigm.com/download/vpuml.jsp'),
(26, NULL, 5, 'IS II', NULL, 'Descargar Visual Paradigm', 'prolsobrado', '2011-09-03 11:47:15', 'http://www.visual-paradigm.com/download/vpuml.jsp'),
(27, NULL, 5, 'RC I', NULL, 'Descargar Wireshark', 'prolsobrado', '2011-09-03 11:47:47', 'http://www.wireshark.org/download.html'),
(28, NULL, 5, 'ATE', NULL, 'Grupo ESEInet', 'prolsobrado', '2011-09-03 11:50:09', 'http://www.eseinet.es/group/administracindelatecnologaylaempresa'),
(30, 13, 3, '', 0, '', 'prolsobrado', '2011-09-03 12:36:27', 'archivos/30.pdf'),
(32, 2, 2, '', 0, '', 'prolsobrado', '2011-09-03 12:42:19', 'archivos/32.pdf'),
(33, 3, 3, '', 0, 'Solución Casa', 'prolsobrado', '2011-09-03 12:45:48', 'archivos/33.doc'),
(34, 3, 3, '', 0, 'Solución Clase', 'prolsobrado', '2011-09-03 12:46:02', 'archivos/34.doc'),
(35, 4, 3, '', 0, 'Solución Casa', 'prolsobrado', '2011-09-03 12:46:24', 'archivos/35.doc'),
(36, 4, 3, '', 0, 'Solución Clase', 'prolsobrado', '2011-09-03 12:46:39', 'archivos/36.doc'),
(38, 2, 2, '', 0, 'Solución con Explicación', 'Ty-tsuky', '2011-09-03 12:52:49', 'archivos/38.pdf'),
(39, 2, 3, '', 0, '', 'Ty-tsuky', '2011-09-03 12:55:52', 'archivos/39.pdf'),
(44, 20, 3, '', 0, '', 'luis', '2011-09-03 13:38:07', 'archivos/44.doc'),
(45, 20, 3, '', 0, '', 'javilorenzo', '2011-09-03 13:39:22', 'archivos/45.pdf'),
(46, 29, 3, '', 0, '', 'prolsobrado', '2011-09-03 14:11:46', 'archivos/46.pdf'),
(47, 29, 3, '', 0, '', 'tronco', '2011-09-03 14:13:01', 'archivos/47.pdf'),
(48, 14, 3, '', 0, '', 'prolsobrado', '2011-09-03 14:14:24', 'archivos/48.doc'),
(49, 15, 3, '', 0, '', 'prolsobrado', '2011-09-03 14:15:00', 'archivos/49.doc'),
(50, 16, 3, '', 0, '', 'prolsobrado', '2011-09-03 14:15:09', 'archivos/50.doc'),
(51, 17, 3, '', 0, '', 'prolsobrado', '2011-09-03 14:15:18', 'archivos/51.doc'),
(52, 18, 3, '', 0, '', 'prolsobrado', '2011-09-03 14:15:35', 'archivos/52.doc'),
(53, 19, 3, '', 0, '', 'prolsobrado', '2011-09-03 14:15:44', 'archivos/53.doc'),
(54, 14, 3, '', 0, 'Semana 3', 'tronco', '2011-09-03 14:19:07', 'archivos/54.rar'),
(55, 14, 3, '', 0, 'Semana 3', 'tronco', '2011-09-03 14:19:16', 'archivos/55.rar'),
(56, 14, 3, '', 0, 'Semana 8', 'tronco', '2011-09-03 14:19:28', 'archivos/56.rar'),
(57, 14, 3, '', 0, 'Semana 10', 'tronco', '2011-09-03 14:19:38', 'archivos/57.zip'),
(58, 14, 3, '', 0, 'Semanas 1 y 2', 'tronco', '2011-09-03 14:19:51', 'archivos/58.rar'),
(59, 14, 3, '', 0, 'Semanas 11 y 12', 'tronco', '2011-09-03 14:20:02', 'archivos/59.rar'),
(60, 14, 3, '', 0, 'Semanas 11, 12 y 13', 'tronco', '2011-09-03 14:20:16', 'archivos/60.zip'),
(62, 30, 3, '', 0, 'Notas Práctica 1', 'prolsobrado', '2011-09-04 10:36:34', 'archivos/62.pdf'),
(63, 31, 3, '', 0, 'Notas Práctica 2', 'prolsobrado', '2011-09-04 10:36:46', 'archivos/63.pdf'),
(64, 33, 3, '', 0, 'Notas Práctica 4', 'prolsobrado', '2011-09-04 10:39:44', 'archivos/64.pdf'),
(65, 34, 3, '', 0, 'Notas Práctica 3', 'prolsobrado', '2011-09-04 10:40:12', 'archivos/65.pdf'),
(66, 40, 3, '', 0, 'Notas Práctica 1', 'prolsobrado', '2011-09-04 10:43:47', 'archivos/66.pdf'),
(67, 41, 3, '', 0, 'Notas Práctica 2', 'prolsobrado', '2011-09-04 10:43:58', 'archivos/67.pdf'),
(68, 42, 3, '', 0, 'Notas Práctica 3', 'prolsobrado', '2011-09-04 10:44:19', 'archivos/68.pdf'),
(70, 34, 3, '', 0, '', 'prolsobrado', '2011-09-04 10:48:05', 'archivos/70.wxm'),
(71, 34, 3, '', 0, '', 'kumar_89', '2011-09-04 10:50:04', 'archivos/71.wxm'),
(72, 34, 3, '', 0, '', 'Gael', '2011-09-04 10:50:25', 'archivos/72.wxm'),
(73, 39, 3, '', 0, '', 'luis', '2011-09-04 10:53:39', 'archivos/73.doc'),
(74, 39, 3, '', 0, '', 'adriansuarez', '2011-09-04 10:56:49', 'archivos/74.doc'),
(77, 43, 3, '', 0, 'Notas Aplicaciones Geométricas', 'prolsobrado', '2011-09-04 11:02:12', 'archivos/77.pdf'),
(78, 43, 3, '', 0, 'Notas Códigos Hamming', 'prolsobrado', '2011-09-04 11:02:29', 'archivos/78.pdf'),
(79, 43, 3, '', 0, '', 'prolsobrado', '2011-09-04 11:03:42', 'archivos/79.docx'),
(80, 0, 4, 'AC II', 2011, 'Soluciones Varias Grupo Reducido', 'prolsobrado', '2011-09-05 08:20:56', 'archivos/80.doc'),
(81, 0, 4, 'AC II', 2011, 'Manuales Micro85', 'prolsobrado', '2011-09-05 08:21:22', 'archivos/81.zip'),
(82, 0, 4, 'AC II', 2011, 'Micro85', 'prolsobrado', '2011-09-05 08:21:35', 'archivos/82.exe'),
(83, 0, 4, 'AC II', 2011, 'Resumen Apuntes', 'prolsobrado', '2011-09-05 08:22:04', 'archivos/83.pdf'),
(84, 0, 4, 'AC I', 2010, 'Instrucciones 8085', 'prolsobrado', '2011-09-05 08:26:50', 'archivos/84.zip'),
(85, 0, 4, 'AC I', 2010, 'Máquina Simple', 'prolsobrado', '2011-09-05 08:27:01', 'archivos/85.zip'),
(86, 0, 4, 'AC I', 2010, 'Simulador 8085', 'prolsobrado', '2011-09-05 08:27:36', 'archivos/86.zip'),
(87, 0, 4, 'AC I', 2010, 'Resumen Apuntes', 'prolsobrado', '2011-09-05 08:28:11', 'archivos/87.pdf'),
(88, 0, 4, 'AL', 2010, 'Guía de Maxima', 'prolsobrado', '2011-09-05 08:35:16', 'archivos/88.pdf'),
(89, 0, 4, 'AL', 2010, 'Soluciones sin determinar (Ejercicios 5 y 6)', 'prolsobrado', '2011-09-05 08:36:22', 'archivos/89.pdf'),
(90, 0, 4, 'AL', 2010, 'Apuntes Aplicaciones Lineales', 'Ty-tsuky', '2011-09-05 08:36:32', 'archivos/90.rar'),
(91, 0, 4, 'AL', 2010, 'Soluciones Ejercicios (2)', 'tronco', '2011-09-05 09:49:17', 'archivos/91.zip'),
(92, 0, 4, 'AL', 2010, 'Soluciones Ejercicios (1)', 'tronco', '2011-09-05 09:49:26', 'archivos/92.zip'),
(93, 0, 4, 'AL', 2010, 'Soluciones Ejercicios (3)', 'tronco', '2011-09-05 09:50:11', 'archivos/93.zip'),
(94, 44, 3, '', 0, 'Escaneos Elmasri', 'prolsobrado', '2011-09-05 12:35:33', 'archivos/94.pdf'),
(95, NULL, 5, 'RC I', NULL, 'Calculadora de Subredes', 'prolsobrado', '2011-09-05 20:45:53', 'http://vlsm-calc.net/'),
(97, NULL, 5, 'IU', NULL, 'Planificación 2011-2012', 'prolsobrado', '2011-09-06 05:18:31', 'http://gig5.ei.uvigo.es/DocenciaDiu20112012/'),
(98, NULL, 5, 'IU', NULL, 'Bolonia Gestión', 'prolsobrado', '2011-09-06 05:24:52', 'http://boloniagestion.com/inicio/login.php'),
(99, 46, 3, '', 0, 'Mejor Solución Antigua', 'prolsobrado', '2011-09-06 10:06:55', 'archivos/99.pdf'),
(100, 0, 4, 'FEJ', 2010, 'Apuntes Ampliados', 'prolsobrado', '2011-09-06 11:24:24', 'archivos/100.pdf'),
(101, 0, 4, 'FEJ', 2010, 'Documentos Interesantes para Prácticas', 'prolsobrado', '2011-09-06 11:28:07', 'archivos/101.zip'),
(102, 0, 4, 'FEJ', 2010, 'Diapositivas Resumen Curso', 'prolsobrado', '2011-09-06 11:28:26', 'archivos/102.ppt'),
(103, NULL, 5, 'FEJ', NULL, 'Agencia Española de Protección de Datos', 'prolsobrado', '2011-09-06 11:34:32', 'https://www.agpd.es/portalwebAGPD/index-ides-idphp.php'),
(104, 0, 4, 'FEJ', 2011, 'STC_292-2000', 'prolsobrado', '2011-09-06 11:39:33', 'archivos/104.pdf'),
(105, 0, 4, 'FEJ', 2011, 'TS_316-2010', 'prolsobrado', '2011-09-06 11:39:43', 'archivos/105.pdf'),
(106, 46, 3, '', 0, 'PortadaEntrega.doc', 'prolsobrado', '2011-09-09 11:57:47', 'archivos/106.doc'),
(107, 46, 3, '', 0, 'Solución de OGSN', 'arfarinha', '2011-09-11 11:51:30', 'archivos/107.rar'),
(108, 46, 3, '', 0, 'Solución', 'prolsobrado', '2011-09-13 00:43:22', 'archivos/108.rar'),
(109, 54, 3, '', 0, '', 'tronco', '2011-09-13 00:55:59', 'archivos/109.pdf'),
(110, 55, 3, '', 0, '', 'tronco', '2011-09-13 00:56:07', 'archivos/110.pdf'),
(210, NULL, 5, 'IU', NULL, 'Control SourceForge', 'prolsobrado', '2011-11-10 10:42:17', 'https://sourceforge.net/p/iucontrol/home/Home/'),
(112, 0, 4, 'IU', 2012, 'Ejercicios PHP', 'Ty-tsuky', '2011-09-13 22:17:43', 'archivos/112.pdf'),
(113, 0, 4, 'IU', 2012, 'Guía HTML', 'Ty-tsuky', '2011-09-13 22:20:21', 'archivos/113.pdf'),
(114, 0, 4, 'IU', 2012, 'Guía PHP', 'Ty-tsuky', '2011-09-13 22:21:16', 'archivos/114.pdf'),
(115, 0, 4, 'IU', 2012, 'Ejercicios PHP Rodeiro', 'prolsobrado', '2011-09-13 22:31:32', 'archivos/115.zip'),
(116, 0, 4, 'HAE', 2012, 'Bibliografía 1', 'prolsobrado', '2011-09-15 00:37:12', 'archivos/116.rar'),
(117, 0, 4, 'HAE', 2012, 'Bibliografía 2', 'prolsobrado', '2011-09-15 00:38:12', 'archivos/117.rar'),
(118, 0, 4, 'HAE', 2012, 'Bibliografía 4', 'prolsobrado', '2011-09-15 00:39:12', 'archivos/118.rar'),
(119, 0, 4, 'HAE', 2012, 'Bibliografía 5', 'prolsobrado', '2011-09-15 00:40:12', 'archivos/119.rar'),
(120, 0, 4, 'HAE', 2012, 'Básicos', 'prolsobrado', '2011-09-15 00:41:12', 'archivos/120.zip'),
(123, 60, 3, '', 0, '', 'prolsobrado', '2011-09-15 11:14:54', 'archivos/123.zip'),
(124, 60, 3, '', 0, '', 'arfarinha', '2011-09-15 12:46:15', 'archivos/124.zip'),
(125, 0, 4, 'HAE', 2012, 'Biblografía 7', 'prolsobrado', '2011-09-15 15:32:25', 'archivos/125.rar'),
(126, 0, 4, 'HAE', 2012, 'DataSheets AIC', 'prolsobrado', '2011-09-15 15:33:25', 'archivos/126.rar'),
(127, 0, 4, 'HAE', 2012, 'Software', 'prolsobrado', '2011-09-15 15:34:25', 'archivos/127.rar'),
(128, 44, 3, '', 0, 'Solución Oficial', 'prolsobrado', '2011-09-15 15:46:28', 'archivos/128.pdf'),
(129, 62, 3, '', 0, 'Solución', 'prolsobrado', '2011-09-19 13:57:56', 'archivos/129.zip'),
(132, 53, 3, '', 0, 'Solución exercicio 8 de HAE(equivoqueime no valor de j, polo tanto non hai que facerlle caso ás dúas primeiras liñas do documento e hai que substituír tódolos signos menos por j)', 'arfarinha', '2011-09-20 21:08:43', 'archivos/132.pdf'),
(133, 0, 4, 'HAE', 2012, 'Rebotes y Contactos', 'prolsobrado', '2011-09-21 13:23:24', 'archivos/133.pdf'),
(134, 0, 4, 'HAE', 2012, 'Micros', 'prolsobrado', '2011-09-21 13:24:06', 'archivos/134.pdf'),
(135, 0, 4, 'HAE', 2012, 'Proteus 7.2', 'prolsobrado', '2011-09-21 13:44:21', 'archivos/135.rar'),
(212, NULL, 5, 'BD II', NULL, 'Servidor Oracle', 'prolsobrado', '2011-11-10 10:46:18', 'https://172.19.30.251:80/em'),
(138, 61, 3, '', 0, 'Solución Oficial', 'prolsobrado', '2011-09-22 14:18:23', 'archivos/138.pdf'),
(139, 64, 3, '', 0, 'Escaneos Grupo 1', 'prolsobrado', '2011-09-22 14:25:22', 'archivos/139.pdf'),
(140, 64, 3, NULL, 0, 'Escaneos Grupo 2', 'prolsobrado', '2011-09-22 14:48:37', 'archivos/140.pdf'),
(141, 64, 3, NULL, 0, 'Escaneos Grupo 3', 'prolsobrado', '2011-09-22 14:56:31', 'archivos/141.pdf'),
(213, NULL, 5, 'IU', NULL, 'Coordinación Proyecto', 'prolsobrado', '2011-11-10 10:47:28', 'http://www.coordina.co.cc/'),
(143, 0, 4, 'HAE', 2012, 'Funciones de Teclado', 'prolsobrado', '2011-09-23 15:03:38', 'archivos/143.rar'),
(144, 62, 3, '', 0, 'Ejemplos', 'prolsobrado', '2011-09-26 12:47:45', 'archivos/144.zip'),
(185, 86, 3, '', 0, 'Ejemplos Python', 'prolsobrado', '2011-10-10 13:15:26', 'archivos/185.zip'),
(148, 55, 3, '', 0, 'Solución', 'prolsobrado', '2011-09-27 17:23:37', 'archivos/148.zip'),
(149, 59, 3, '', 0, 'Solución', 'prolsobrado', '2011-09-27 17:24:19', 'archivos/149.zip'),
(150, 66, 3, '', 0, 'Solución', 'prolsobrado', '2011-09-27 17:24:48', 'archivos/150.zip'),
(151, 0, 4, 'HAE', 2012, 'Prácticas', 'prolsobrado', '2011-09-28 11:39:58', 'archivos/151.pdf'),
(152, 51, 3, '', 0, '', 'luis', '2011-10-02 14:14:56', 'archivos/152.doc'),
(153, 50, 3, '', 0, '', 'luis', '2011-10-02 14:15:07', 'archivos/153.doc'),
(154, 49, 3, '', 0, '', 'luis', '2011-10-02 14:15:14', 'archivos/154.doc'),
(155, 78, 3, '', 0, 'Trabajo sobre Spam', 'saul', '2011-10-02 14:16:29', 'archivos/155.docx'),
(156, 78, 3, '', 0, 'Trabajo sobre El Control de la Información', 'luis', '2011-10-02 14:18:12', 'archivos/156.zip'),
(157, 0, 4, 'FEJ', 2011, 'Documento de Seguridad', 'saul', '2011-10-02 14:18:28', 'archivos/157.docx'),
(158, 0, 4, 'FEJ', 2010, 'Documento de Seguridad', 'prolsobrado', '2011-10-02 14:24:58', 'archivos/158.doc'),
(159, 79, 3, '', 0, 'Trabajo 2', 'prolsobrado', '2011-10-02 14:26:03', 'archivos/159.zip'),
(160, 79, 3, '', 0, 'Trabajo 1', 'prolsobrado', '2011-10-02 14:26:06', 'archivos/160.ppt'),
(161, 0, 4, 'EST', 2011, 'Resumen Apuntes', 'prolsobrado', '2011-10-02 14:28:50', 'archivos/161.pdf'),
(162, 0, 4, 'AED I', 2010, 'Compilación de Archivos', 'prolsobrado', '2011-10-02 00:00:00', 'archivos/162.zip'),
(163, 0, 4, 'AED II', 2011, 'Compilación de Archivos', 'prolsobrado', '2011-10-02 00:00:00', 'archivos/163.zip'),
(164, 0, 4, 'AM', 2010, 'Compilación de Archivos', 'prolsobrado', '2011-10-02 00:00:00', 'archivos/164.zip'),
(165, 0, 4, 'AP', 2011, 'Compilación de Archivos', 'prolsobrado', '2011-10-02 00:00:00', 'archivos/165.zip'),
(166, 0, 4, 'ATE', 2010, 'Compilación de Archivos', 'prolsobrado', '2011-10-02 00:00:00', 'archivos/166.zip'),
(167, 0, 4, 'BD I', 2011, 'Compilación de Archivos', 'prolsobrado', '2011-10-02 00:00:00', 'archivos/167.zip'),
(168, 0, 4, 'EST', 2011, 'Compilación de Archivos', 'prolsobrado', '2011-10-02 00:00:00', 'archivos/168.zip'),
(169, 0, 4, 'IS I', 2011, 'Compilación de Archivos', 'prolsobrado', '2011-10-02 00:00:00', 'archivos/169.zip'),
(170, 0, 4, 'IS II', 2011, 'Compilación de Archivos', 'prolsobrado', '2011-10-02 00:00:00', 'archivos/170.zip'),
(171, 0, 4, 'FMI', 2010, 'Compilación de Archivos', 'prolsobrado', '2011-10-02 00:00:00', 'archivos/171.zip'),
(172, 0, 4, 'PRO I', 2010, 'Compilación de Archivos', 'prolsobrado', '2011-10-02 00:00:00', 'archivos/172.zip'),
(173, 0, 4, 'PRO II', 2010, 'Compilación de Archivos', 'prolsobrado', '2011-10-02 00:00:00', 'archivos/173.zip'),
(174, 0, 4, 'RC I', 2011, 'Compilación de Archivos', 'prolsobrado', '2011-10-02 00:00:00', 'archivos/174.zip'),
(175, 0, 4, 'SD', 2010, 'Compilación de Archivos', 'prolsobrado', '2011-10-02 00:00:00', 'archivos/175.zip'),
(176, 0, 4, 'SO I', 2011, 'Compilación de Archivos', 'prolsobrado', '2011-10-02 00:00:00', 'archivos/176.zip'),
(177, 0, 4, 'SO II', 2011, 'Compilación de Archivos', 'prolsobrado', '2011-10-02 00:00:00', 'archivos/177.zip'),
(178, 75, 3, '', 0, 'Solución', 'prolsobrado', '2011-10-04 16:43:50', 'archivos/178.zip'),
(194, 86, 3, '', 0, 'Solución', 'prolsobrado', '2011-10-23 23:34:18', 'archivos/194.zip'),
(180, 0, 4, 'BD II', 2012, 'Guía de Prácticas', 'prolsobrado', '2011-10-08 16:56:01', 'archivos/180.pdf'),
(181, 0, 4, 'BD II', 2012, 'Planificación de Prácticas', 'prolsobrado', '2011-10-08 16:56:18', 'archivos/181.pdf'),
(182, 0, 4, 'HAE', 2012, 'Tipos de Datos', 'prolsobrado', '2011-10-08 16:59:05', 'archivos/182.pdf'),
(183, 0, 4, 'HAE', 2012, 'Sistemas y Señales', 'prolsobrado', '2011-10-08 17:27:13', 'archivos/183.pdf'),
(184, 68, 3, '', 0, 'Solución', 'prolsobrado', '2011-10-09 16:49:14', 'archivos/184.zip'),
(187, 0, 4, 'HAE', 2012, 'Apuntes Prácticas', 'prolsobrado', '2011-10-11 16:25:57', 'archivos/187.pdf'),
(188, 81, 3, '', 0, 'Solución A', 'prolsobrado', '2011-10-12 12:46:33', 'archivos/188.zip'),
(189, 81, 3, '', 0, 'Solución D', 'prolsobrado', '2011-10-18 13:37:39', 'archivos/189.zip'),
(190, 88, 3, '', 0, 'Solución', 'prolsobrado', '2011-10-18 22:57:27', 'archivos/190.rar'),
(191, 87, 3, '', 0, 'Solución Oficial', 'prolsobrado', '2011-10-18 23:09:35', 'archivos/191.pdf'),
(192, 85, 3, '', 0, 'Diapositivas buenas para reaprender xD', 'prolsobrado', '2011-10-19 18:28:03', 'archivos/192.pdf'),
(193, 89, 3, '', 0, 'Escaneos', 'prolsobrado', '2011-10-19 19:56:40', 'archivos/193.pdf'),
(195, 91, 3, '', 0, 'Material', 'prolsobrado', '2011-10-24 13:11:09', 'archivos/195.zip'),
(207, NULL, 5, 'IU', NULL, 'PHP My Admin GIG5', 'prolsobrado', '2011-11-10 10:36:46', 'http://gig5.ei.uvigo.es/phpmyadmin/'),
(197, 81, 3, '', 0, 'Solución C', 'prolsobrado', '2011-10-25 14:33:19', 'archivos/197.zip'),
(198, 89, 3, '', 0, 'Solución Oficial', 'prolsobrado', '2011-10-27 01:28:32', 'archivos/198.pdf'),
(199, 93, 3, '', 0, 'Modelo', 'prolsobrado', '2011-10-27 16:15:57', 'archivos/199.doc'),
(200, 94, 3, '', 0, 'Colector de Basura', 'prolsobrado', '2011-10-27 16:18:45', 'archivos/200.pdf'),
(201, 94, 3, '', 0, 'Estruturas iterativas en Python i en C: o bucle for', 'arfarinha', '2011-10-27 16:19:09', 'archivos/201.pptx'),
(202, 65, 3, '', 0, 'Solución', 'prolsobrado', '2011-10-28 11:49:22', 'archivos/202.zip'),
(204, 95, 3, '', 0, 'Solución', 'prolsobrado', '2011-10-28 11:52:36', 'archivos/204.zip'),
(205, 80, 3, '', 0, '', 'prolsobrado', '2011-10-28 11:53:19', 'archivos/205.rar'),
(206, 85, 3, '', 0, 'Solución', 'prolsobrado', '2011-10-28 12:54:45', 'archivos/206.pdf'),
(211, NULL, 5, 'BD II', NULL, 'FTP Oracle', 'prolsobrado', '2011-11-10 10:45:39', 'ftp://172.19.30.251'),
(209, NULL, 5, 'IU', NULL, 'Máquina Virtual', 'prolsobrado', '2011-11-10 10:38:15', 'http://gig5.ei.uvigo.es/DocenciaDiu20112012/MaquinaVirtualAlumnosBridge.7z'),
(214, 101, 3, '', 0, 'Anexo', 'prolsobrado', '2012-01-12 18:11:19', 'archivos/214.pdf'),
(215, 93, 3, '', 0, 'Solución', 'prolsobrado', '2012-01-12 18:11:59', 'archivos/215.zip'),
(216, 107, 3, '', 0, 'Solución', 'prolsobrado', '2012-01-12 18:12:07', 'archivos/216.zip'),
(217, 110, 3, '', 0, 'Modelo', 'prolsobrado', '2012-01-12 18:15:26', 'archivos/217.doc'),
(218, 0, 4, 'BD II', 2012, 'SQL Developer (Intrucciones)', 'prolsobrado', '2012-01-12 18:15:42', 'archivos/218.txt'),
(219, 0, 4, 'HAE', 2012, 'Filtros', 'prolsobrado', '2012-01-12 18:16:50', 'archivos/219.pdf'),
(220, 0, 4, 'HAE', 2012, 'I2C-SPI', 'prolsobrado', '2012-01-12 18:16:58', 'archivos/220.pdf'),
(221, 104, 3, '', 0, 'Solución', 'prolsobrado', '2012-01-12 18:17:46', 'archivos/221.zip'),
(222, 105, 3, '', 0, 'Solución', 'prolsobrado', '2012-01-12 18:18:06', 'archivos/222.zip'),
(223, 100, 3, '', 0, 'Solución', 'prolsobrado', '2012-01-12 18:19:22', 'archivos/223.zip'),
(224, 100, 3, '', 0, 'Datasheets', 'prolsobrado', '2012-01-12 18:19:37', 'archivos/224.zip'),
(225, 109, 3, '', 0, 'Solución', 'prolsobrado', '2012-01-12 18:22:54', 'archivos/225.zip'),
(226, 112, 3, '', 0, 'Solución', 'prolsobrado', '2012-01-12 18:24:23', 'archivos/226.zip'),
(227, 111, 3, '', 0, 'Solución', 'prolsobrado', '2012-01-12 18:24:29', 'archivos/227.zip'),
(228, 0, 4, 'HAE', 2012, 'Todas las prácticas de laboratorio', 'prolsobrado', '2012-01-12 18:26:30', 'archivos/228.zip'),
(229, 108, 3, '', 0, 'Solución', 'prolsobrado', '2012-01-12 18:26:34', 'archivos/229.rar'),
(230, 103, 3, '', 0, 'Solución', 'prolsobrado', '2012-01-12 18:27:19', 'archivos/230.pdf'),
(231, 113, 3, '', 0, 'Solución', 'prolsobrado', '2012-01-12 18:29:01', 'archivos/231.zip'),
(232, 9, 2, '', 0, 'Exámenes Anteriores', 'prolsobrado', '2012-01-12 18:30:50', 'archivos/232.zip'),
(233, 91, 3, '', 0, 'Solución', 'prolsobrado', '2012-01-12 18:32:45', 'archivos/233.zip'),
(234, 99, 3, '', 0, 'Material', 'prolsobrado', '2012-01-12 18:32:57', 'archivos/234.zip'),
(235, 99, 3, '', 0, 'Solución', 'prolsobrado', '2012-01-12 18:33:07', 'archivos/235.zip'),
(236, 114, 3, '', 0, 'Material', 'prolsobrado', '2012-01-12 18:33:27', 'archivos/236.zip'),
(237, 114, 3, '', 0, 'Solución', 'prolsobrado', '2012-01-12 18:33:36', 'archivos/237.zip'),
(238, 115, 3, '', 0, 'Material', 'prolsobrado', '2012-01-12 18:33:44', 'archivos/238.zip'),
(239, 115, 3, '', 0, 'Solución', 'prolsobrado', '2012-01-12 18:33:54', 'archivos/239.zip'),
(240, 97, 3, '', 0, 'Soluciones', 'prolsobrado', '2012-01-12 18:35:43', 'archivos/240.zip'),
(241, 116, 3, '', 0, 'Soluciones', 'prolsobrado', '2012-01-12 18:37:28', 'archivos/241.zip'),
(242, 12, 2, '', 0, 'Solución Oficial', 'prolsobrado', '2012-01-12 18:38:20', 'archivos/242.pdf'),
(243, 94, 3, '', 0, 'Todos', 'prolsobrado', '2012-01-12 18:38:22', 'archivos/243.zip'),
(244, 13, 2, '', 0, 'Solución Oficial', 'prolsobrado', '2012-01-12 18:38:25', 'archivos/244.pdf'),
(245, 14, 2, '', 0, 'Solución Oficial', 'prolsobrado', '2012-01-12 18:38:32', 'archivos/245.pdf'),
(246, NULL, 5, 'HAE', NULL, 'Apuntes', 'prolsobrado', '2012-01-18 18:34:10', 'http://gl.eei.wikia.com/wiki/HAE'),
(247, 0, 4, 'SI', 2012, 'Plantilla de Trabajos', 'prolsobrado', '2012-01-24 15:49:47', 'archivos/247.doc'),
(248, NULL, 5, 'SO II', NULL, 'Horas de dedicación', 'prolsobrado', '2012-01-24 15:50:58', 'http://so2.atopa.me/registro/'),
(249, NULL, 5, 'CDA', NULL, 'Horas de dedicación', 'prolsobrado', '2012-01-24 15:51:08', 'http://cdatos.atopa.me/registro'),
(317, 0, 4, 'SI', 2012, 'Búsqueda a Ciegas 2', 'prolsobrado', '2012-03-22 09:17:24', 'archivos/317.pdf'),
(251, NULL, 5, 'DGP', NULL, 'Web de DGP', 'prolsobrado', '2012-01-25 15:06:52', 'http://193.147.87.250/efront/www/index.php'),
(252, 123, 3, '', 0, 'MP3 en texto', 'prolsobrado', '2012-01-28 04:27:13', 'archivos/252.pdf'),
(253, 121, 3, '', 0, 'Solución', 'prolsobrado', '2012-01-30 10:27:05', 'archivos/253.zip'),
(265, 124, 3, '', 0, 'Pruebas TrollServer', 'prolsobrado', '2012-02-13 09:45:19', 'archivos/265.zip'),
(255, 123, 3, '', 0, 'Resumen comentado', 'prolsobrado', '2012-01-31 23:58:36', 'archivos/255.pdf'),
(256, 125, 3, '', 0, 'Solución', 'prolsobrado', '2012-02-01 18:22:17', 'archivos/256.pdf'),
(257, 125, 3, '', 0, 'Entregable FaiTIC', 'prolsobrado', '2012-02-01 23:11:14', 'archivos/257.pdf'),
(316, 0, 4, 'SI', 2012, 'Búsqueda a Ciegas 1', 'prolsobrado', '2012-03-22 09:17:15', 'archivos/316.pdf'),
(259, 126, 3, '', 0, 'Diagrama de Gantt', 'prolsobrado', '2012-02-02 17:32:18', 'archivos/259.pdf'),
(260, 120, 3, '', 0, 'Volcado de SportCenter', 'prolsobrado', '2012-02-08 09:50:16', 'archivos/260.zip'),
(261, 129, 3, '', 0, 'Archivos de FaiTIC', 'prolsobrado', '2012-02-08 12:39:57', 'archivos/261.zip'),
(264, 129, 3, '', 0, 'Solución', 'prolsobrado', '2012-02-10 13:28:40', 'archivos/264.zip'),
(263, 124, 3, '', 0, '	EVServer (Actualizado serverImplementation.sh)', 'prolsobrado', '2012-02-08 17:16:25', 'archivos/263.zip'),
(266, 0, 4, 'SI', 2012, 'Inteligencia Artificial en Prolog', 'prolsobrado', '2012-02-14 22:04:23', 'archivos/266.pdf'),
(282, 135, 3, '', 0, 'Solución Mi Familia', 'prolsobrado', '2012-02-23 12:09:40', 'archivos/282.zip'),
(315, NULL, 5, 'PL', NULL, 'Horas de dedicación', 'prolsobrado', '2012-03-21 16:53:11', 'http://xistral.ei.uvigo.es:8080/PL/'),
(276, 0, 4, 'CDA', 2012, 'Características Coraid', 'prolsobrado', '2012-02-22 10:01:33', 'archivos/276.pdf'),
(277, 0, 4, 'CDA', 2012, 'Manual Coraid', 'prolsobrado', '2012-02-22 10:01:39', 'archivos/277.pdf'),
(325, 130, 3, '', 0, 'Solución Oficial', 'prolsobrado', '2012-04-12 00:29:24', 'archivos/325.pdf'),
(273, NULL, 5, 'SI', NULL, 'Learn Prolog!', 'prolsobrado', '2012-02-18 15:40:22', 'http://www.learnprolognow.org/lpnpage.php?pageid=online'),
(274, NULL, 5, 'SI', NULL, 'Árbol Genealógico en Prolog', 'prolsobrado', '2012-02-18 15:40:44', 'http://swi-prolog.blogspot.com/2010/06/arbol-genealogico.html'),
(275, 0, 4, 'SI', 2012, 'Presentación interesante sobre Prolog', 'prolsobrado', '2012-02-18 15:40:59', 'archivos/275.ppt'),
(296, 140, 3, '', 0, 'Solución', 'prolsobrado', '2012-03-08 13:38:47', 'archivos/296.zip'),
(279, 133, 3, '', 0, 'Solución', 'prolsobrado', '2012-02-23 00:44:18', 'archivos/279.zip'),
(292, 117, 3, '', 0, 'Mi trabajo', 'prolsobrado', '2012-03-06 23:49:05', 'archivos/292.pdf'),
(289, 137, 3, '', 0, 'Solución', 'prolsobrado', '2012-03-01 14:30:30', 'archivos/289.zip'),
(290, 139, 3, '', 0, 'Archivos', 'prolsobrado', '2012-03-05 09:52:18', 'archivos/290.zip'),
(306, 143, 3, '', 0, 'Solución', 'prolsobrado', '2012-03-13 11:58:43', 'archivos/306.sh'),
(297, NULL, 5, 'SO II', NULL, 'Aprender Socat', 'prolsobrado', '2012-03-09 11:17:31', 'http://jdimpson.livejournal.com/6534.html'),
(295, 138, 3, '', 0, 'Solución', 'prolsobrado', '2012-03-07 14:46:09', 'archivos/295.zip'),
(298, NULL, 5, 'CDA', NULL, 'Aprender Socat', 'prolsobrado', '2012-03-09 11:17:42', 'http://jdimpson.livejournal.com/6534.html'),
(299, 135, 3, '', 0, 'Últimas diapositivas', 'prolsobrado', '2012-03-09 11:25:34', 'archivos/299.zip'),
(300, 0, 4, 'CDA', 2012, 'Manual VPN', 'prolsobrado', '2012-03-10 14:32:44', 'archivos/300.pdf'),
(311, NULL, 5, 'DGP', NULL, 'INTECO', 'prolsobrado', '2012-03-15 09:45:19', 'http://inteco.es/calidad_TIC/descargas/guias/'),
(302, 0, 4, 'DGP', 2012, 'Prácticas Microsoft Project', 'prolsobrado', '2012-03-12 21:23:13', 'archivos/302.mpp'),
(303, 0, 4, 'SI', 2012, 'Listas de Prolog', 'prolsobrado', '2012-03-13 10:03:17', 'archivos/303.pdf'),
(304, 0, 4, 'SI', 2012, 'Tutorial de Prolog', 'prolsobrado', '2012-03-13 10:03:31', 'archivos/304.pdf'),
(312, 135, 3, '', 0, 'Bot EViS', 'prolsobrado', '2012-03-20 11:01:34', 'archivos/312.zip'),
(309, 141, 3, '', 0, 'Solución', 'prolsobrado', '2012-03-14 03:20:15', 'archivos/309.zip'),
(319, 146, 3, '', 0, 'Solución', 'prolsobrado', '2012-03-28 14:03:15', 'archivos/319.zip'),
(323, 151, 3, '', 0, 'Solución', 'prolsobrado', '2012-04-10 23:45:05', 'archivos/323.zip'),
(314, NULL, 5, 'CDI', NULL, 'Web de CDI', 'prolsobrado', '2012-03-21 16:43:39', 'http://trevinca.ei.uvigo.es/~formella/doc/cdg11/index.html'),
(318, 0, 4, 'CDI', 2012, 'Java Oracle Essentials', 'prolsobrado', '2012-03-22 09:17:47', 'archivos/318.pdf'),
(321, 148, 3, '', 0, 'Mi trabajo', 'prolsobrado', '2012-04-09 18:56:58', 'archivos/321.pdf'),
(322, 154, 3, '', 0, 'Solución', 'prolsobrado', '2012-04-10 12:40:24', 'archivos/322.pdf'),
(324, 156, 3, '', 0, 'Solución', 'prolsobrado', '2012-04-12 00:25:36', 'archivos/324.zip'),
(326, NULL, 5, 'DGP', NULL, 'CiteSeerX', 'prolsobrado', '2012-04-12 09:37:03', 'http://citeseerx.ist.psu.edu/index'),
(327, NULL, 5, 'DGP', NULL, 'Librería ACM', 'prolsobrado', '2012-04-12 09:37:34', 'http://dl.acm.org/'),
(328, NULL, 5, 'DGP', NULL, 'Google Scholar', 'prolsobrado', '2012-04-12 09:37:46', 'http://scholar.google.es/'),
(329, 0, 4, 'PL', 2012, 'Algoritmos Análisis Sintáctico', 'prolsobrado', '2012-04-13 03:01:59', 'archivos/329.pdf'),
(330, 122, 3, '', 0, 'Solución', 'prolsobrado', '2012-04-13 22:28:43', 'archivos/330.zip'),
(331, 134, 3, '', 0, 'Solución', 'prolsobrado', '2012-04-13 22:29:52', 'archivos/331.zip'),
(334, 153, 3, '', 0, 'Solución Oficial', 'prolsobrado', '2012-04-21 15:45:15', 'archivos/334.pdf'),
(333, 157, 3, '', 0, 'Solución de la práctica 4B', 'pmkirsten', '2012-04-19 00:47:47', 'archivos/333.zip'),
(335, 165, 3, '', 0, 'Solución', 'prolsobrado', '2012-04-21 15:46:01', 'archivos/335.zip'),
(336, 164, 3, '', 0, 'Solución', 'rramilo', '2012-04-25 13:37:43', 'archivos/336.zip'),
(337, 167, 3, '', 0, 'Incompleto', 'rramilo', '2012-04-25 14:21:58', 'archivos/337.zip'),
(346, 158, 3, '', 0, 'Decisiones Bayesanas (Texto)', 'prolsobrado', '2012-05-09 03:53:08', 'archivos/346.pdf'),
(339, 161, 3, '', 0, '4.2 Tablas de Símbolos', 'prolsobrado', '2012-04-30 10:00:11', 'archivos/339.zip'),
(340, 161, 3, '', 0, '4.3 Tipos de Datos y Verificación de Tipos', 'prolsobrado', '2012-04-30 10:00:52', 'archivos/340.zip'),
(341, 0, 4, 'SO II', 2012, 'Ejemplo de Examen', 'prolsobrado', '2012-04-30 10:03:00', 'archivos/341.pdf'),
(342, 169, 3, '', 0, 'Solución', 'prolsobrado', '2012-04-30 22:52:44', 'archivos/342.zip'),
(343, 167, 3, '', 0, 'Incompleto 2', 'rramilo', '2012-05-02 13:54:17', 'archivos/343.zip'),
(344, 171, 3, '', 0, 'Solución Oficial', 'prolsobrado', '2012-05-03 00:21:47', 'archivos/344.pdf'),
(345, 132, 3, '', 0, 'Servidor LDAP', 'prolsobrado', '2012-05-04 20:00:29', 'archivos/345.pdf'),
(347, 158, 3, '', 0, 'Decisiones Bayesanas (Presentación)', 'prolsobrado', '2012-05-09 03:53:32', 'archivos/347.pdf'),
(348, 161, 3, '', 0, '5 Ambientes de Ejecución', 'prolsobrado', '2012-05-13 19:22:02', 'archivos/348.zip'),
(349, 161, 3, '', 0, '6 Generación de Código Intermedio', 'prolsobrado', '2012-05-13 19:22:10', 'archivos/349.zip'),
(350, 161, 3, '', 0, '7 Generación de Código Objeto', 'prolsobrado', '2012-05-13 19:22:36', 'archivos/350.zip'),
(351, 174, 3, '', 0, 'Archivos', 'prolsobrado', '2012-05-14 19:10:44', 'archivos/351.zip'),
(352, 0, 4, 'CDA', 2012, 'Como diseñar un CPD', 'prolsobrado', '2012-05-16 22:29:33', 'archivos/352.pdf'),
(353, 161, 3, '', 0, '8 Optimización de Código', 'prolsobrado', '2012-05-19 15:51:20', 'archivos/353.zip'),
(355, 161, 3, '', 0, '9.1 JVM', 'prolsobrado', '2012-05-19 15:51:36', 'archivos/355.zip'),
(356, 161, 3, '', 0, '9.2 GCC', 'prolsobrado', '2012-05-19 15:51:45', 'archivos/356.zip');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asignatura`
--

CREATE TABLE IF NOT EXISTS `asignatura` (
  `idAsignatura` varchar(6) NOT NULL,
  `nombreAsignatura` varchar(50) NOT NULL,
  `curso` int(1) NOT NULL,
  `cuadrimestre` int(1) NOT NULL,
  PRIMARY KEY (`idAsignatura`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `asignatura`
--

INSERT INTO `asignatura` (`idAsignatura`, `nombreAsignatura`, `curso`, `cuadrimestre`) VALUES
('AC I', 'Arquitectura de Computadoras I', 1, 2),
('AC II', 'Arquitectura de Computadoras II', 2, 1),
('AED I', 'Algoritmos y Estructuras de Datos I', 1, 2),
('AED II', 'Algoritmos y Estructuras de Datos II', 2, 1),
('AL', 'Álgebra Lineal', 1, 1),
('AM', 'Análisis Matemático', 1, 2),
('AP', 'Arquitecturas Paralelas', 2, 2),
('ATE', 'Administración de la Tecnología y la Empresa', 1, 2),
('BD I', 'Bases de Datos I', 2, 2),
('BD II', 'Bases de Datos II', 3, 1),
('CDA', 'Centros de Datos', 3, 2),
('CDI', 'Concurrencia y Distribución', 3, 2),
('DGP', 'Dirección y Gestión de Proyectos', 3, 2),
('EST', 'Estadística', 2, 1),
('FEJ', 'Fundamentos Éticos y Jurídicos de las TIC', 1, 1),
('FMI', 'Fundamentos Matemáticos de la Informática', 1, 1),
('HAE', 'Hardware de Aplicación Específica', 3, 1),
('IS I', 'Ingeniería del Software I', 2, 1),
('IS II', 'Ingeniería del Software II', 2, 2),
('IU', 'Interfaces de Usuario', 3, 1),
('LPR', 'Lenguajes de Programación', 3, 1),
('PL', 'Procesadores de Lenguaje', 3, 2),
('PRO I', 'Programación I', 1, 1),
('PRO II', 'Programación II', 1, 2),
('RC I', 'Redes de Computadoras I', 2, 2),
('RC II', 'Redes de Computadoras II', 3, 1),
('SD', 'Sistemas Digitales', 1, 1),
('SI', 'Sistemas Inteligentes', 3, 2),
('SO I', 'Sistemas Operativos I', 2, 1),
('SO II', 'Sistemas Operativos II', 2, 2),
('ABP', 'Aprendizaje Basado en Proyectos', 4, 1),
('SSI', 'Seguridad en Sistemas Informáticos', 4, 1),
('DAI', 'Desarrollo de Aplicaciones para Internet', 4, 1),
('IG', 'Informática Gráfica', 4, 1),
('TAMI', 'Técnicas Avanzadas de Manejo de Información', 4, 1),
('TSW', 'Tecnologías y Servicios Web', 4, 1),
('TCL', 'Técnicas de Comunicación y Liderazgo', 4, 2),
('CC', 'Codificación y Criptografía', 4, 2),
('DET', 'Dirección Estratégica de las TIC', 4, 2),
('DM', 'Dispositivos Móviles', 4, 2),
('PFG', 'Proyecto de Fin de Grado', 4, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentario`
--

CREATE TABLE IF NOT EXISTS `comentario` (
  `idComentario` int(10) NOT NULL,
  `idArchivo` int(10) NOT NULL,
  `nombreUsuario` varchar(50) NOT NULL,
  `fechaComentario` datetime NOT NULL,
  `contenido` varchar(1000) NOT NULL,
  PRIMARY KEY (`idComentario`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `comentario`
--

INSERT INTO `comentario` (`idComentario`, `idArchivo`, `nombreUsuario`, `fechaComentario`, `contenido`) VALUES
(4, 207, 'prolsobrado', '2011-11-10 10:39:51', 'Usuario: scuser\r\nContraseña: scpass'),
(5, 209, 'prolsobrado', '2011-11-10 10:40:53', 'Usuario: root\r\nContraseña: diu'),
(6, 209, 'prolsobrado', '2011-11-10 10:41:20', 'Dirección IP: 192.168.30.128'),
(8, 212, 'prolsobrado', '2011-11-10 10:46:37', 'Usuario: ADBD1, ADBD2, ADBD3\r\nContraseña: ADBD1, ADBD2, ADBD3');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compartir`
--

CREATE TABLE IF NOT EXISTS `compartir` (
  `idArchivo` int(10) NOT NULL,
  `nombreUsuario` varchar(50) NOT NULL,
  PRIMARY KEY (`idArchivo`,`nombreUsuario`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `docente`
--

CREATE TABLE IF NOT EXISTS `docente` (
  `idAsignatura` varchar(6) NOT NULL,
  `idProfesor` int(2) NOT NULL,
  PRIMARY KEY (`idAsignatura`,`idProfesor`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `docente`
--

INSERT INTO `docente` (`idAsignatura`, `idProfesor`) VALUES
('AC I', 9),
('AC I', 10),
('AC I', 11),
('AC II', 9),
('AC II', 10),
('AC II', 11),
('AED I', 12),
('AED I', 13),
('AED I', 14),
('AED II', 12),
('AED II', 13),
('AED II', 22),
('AL', 1),
('AL', 2),
('AL', 3),
('AM', 15),
('AP', 9),
('AP', 25),
('ATE', 16),
('ATE', 17),
('ATE', 18),
('BD I', 26),
('BD II', 31),
('BD II', 32),
('BD II', 33),
('BD II', 34),
('CDA', 30),
('CDA', 39),
('CDA', 40),
('CDI', 22),
('CDI', 41),
('DGP', 42),
('EST', 23),
('FEJ', 4),
('FMI', 2),
('HAE', 7),
('IS I', 24),
('IS II', 18),
('IS II', 27),
('IU', 35),
('LPR', 36),
('LPR', 37),
('PL', 13),
('PL', 43),
('PRO I', 5),
('PRO I', 6),
('PRO II', 19),
('PRO II', 20),
('PRO II', 21),
('RC I', 28),
('RC II', 9),
('RC II', 38),
('SD', 7),
('SD', 8),
('SI', 44),
('SI', 45),
('SO I', 5),
('SO I', 20),
('SO II', 29),
('SO II', 30);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `documento`
--

CREATE TABLE IF NOT EXISTS `documento` (
  `idDocumento` int(10) NOT NULL,
  `idAsignatura` varchar(6) NOT NULL,
  `tipoDocumento` varchar(20) NOT NULL,
  `numeracion` int(2) DEFAULT NULL,
  `descripcion` varchar(1000) DEFAULT NULL,
  `enlace` varchar(500) DEFAULT NULL,
  `curso` int(4) NOT NULL,
  PRIMARY KEY (`idDocumento`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `documento`
--

INSERT INTO `documento` (`idDocumento`, `idAsignatura`, `tipoDocumento`, `numeracion`, `descripcion`, `enlace`, `curso`) VALUES
(2, 'AC II', 'Tema Teoría', 1, 'Memoria Parte 1', 'documentos/2.pdf', 2011),
(3, 'AC II', 'Tema Teoría', 1, 'Memoria Parte 2', 'documentos/3.pdf', 2011),
(4, 'AC II', 'Tema Teoría', 1, 'Memoria Parte 3', 'documentos/4.pdf', 2011),
(5, 'AC II', 'Tema Teoría', 2, 'Memoria Secundaria', 'documentos/5.pdf', 2011),
(6, 'AC II', 'Tema Teoría', 3, 'Entrada-Salida', 'documentos/6.pdf', 2011),
(7, 'AC II', 'Tema Teoría', 4, 'Buses', 'documentos/7.pdf', 2011),
(8, 'AC I', 'Documentación', 0, 'Arquitectura Von-Neumann', 'documentos/8.pdf', 2010),
(9, 'AC I', 'Tema Teoría', 1, 'Introducción', 'documentos/9.pdf', 2010),
(11, 'AC I', 'Tema Teoría', 2, 'Modos de Direccionamiento', 'documentos/11.pdf', 2010),
(13, 'AC I', 'Tema Teoría', 3, 'Operadores', 'documentos/13.pdf', 2010),
(15, 'AC I', 'Tema Teoría', 4, 'Unidad de Proceso', 'documentos/15.pdf', 2010),
(17, 'AC I', 'Tema Teoría', 5, 'Unidad de Control', 'documentos/17.pdf', 2010),
(18, 'AC I', 'Tema Teoría', 6, 'Memoria', 'documentos/18.pdf', 2010),
(19, 'AC I', 'Tema Teoría', 7, 'Entrada y Salida', 'documentos/19.pdf', 2010),
(20, 'AC I', 'Tema Teoría', 0, 'Introducción', 'documentos/20.pdf', 2011),
(21, 'AC I', 'Tema Teoría', 1, 'Memoria', 'documentos/21.pdf', 2011),
(22, 'AC I', 'Tema Teoría', 2, 'Operadores', 'documentos/22.pps', 2011),
(23, 'AC I', 'Tema Teoría', 3, 'Direccionamientos', 'documentos/23.pps', 2011),
(24, 'AC I', 'Tema Teoría', 4, 'Unidad de Control', 'documentos/24.pps', 2011),
(25, 'AC I', 'Tema Teoría', 5, 'Unidad de Proceso', 'documentos/25.pps', 2011),
(26, 'AC I', 'Tema Teoría', 6, 'Entrada y Salida', 'documentos/26.pps', 2011),
(27, 'AC I', 'Tema Teoría', 7, 'Buses', 'documentos/27.pdf', 2011),
(28, 'AL', 'Tema Teoría', 1, 'Espacios Vectoriales 1', 'documentos/28.pdf', 2010),
(29, 'AL', 'Tema Teoría', 1, 'Espacios Vectoriales 2', 'documentos/29.pdf', 2010),
(30, 'AL', 'Tema Teoría', 1, 'Espacios Vectoriales 3', 'documentos/30.pdf', 2010),
(31, 'AL', 'Tema Teoría', 1, 'Espacios Vectoriales 4', 'documentos/31.pdf', 2010),
(32, 'AL', 'Tema Teoría', 2, 'Aplicaciones Lineales y Estructura de los Endomorfismos 1', 'documentos/32.pdf', 2010),
(33, 'AL', 'Tema Teoría', 2, 'Aplicaciones Lineales y Estructura de los Endomorfismos 2', 'documentos/33.pdf', 2010),
(34, 'AL', 'Tema Teoría', 3, 'Espacios Vectoriales Euclideanos', 'documentos/34.pdf', 2010),
(35, 'AL', 'Documentación', 0, 'Códigos Hamming', 'documentos/35.zip', 2010),
(36, 'BD II', 'Tema Práctica', 1, 'Arquitectura Lógica', 'documentos/36.pdf', 2012),
(37, 'IU', 'Tema Teoría', 1, 'Técnicas de Representación', 'documentos/37.pdf', 2012),
(38, 'IU', 'Tema Práctica', 1, 'Introducción a Internet, Redes de Comunicaciones, Servicios, Cliente-Servidor', 'documentos/38.zip', 2012),
(39, 'FEJ', 'Tema Teoría', 1, '(1)', 'documentos/39.pdf', 2010),
(40, 'FEJ', 'Tema Teoría', 2, '(1)', 'documentos/40.pdf', 2010),
(41, 'FEJ', 'Tema Teoría', 1, '(2)', 'documentos/41.pdf', 2010),
(42, 'FEJ', 'Tema Teoría', 2, '(2)', 'documentos/42.pdf', 2010),
(43, 'FEJ', 'Tema Teoría', 1, '(1)', 'documentos/43.pdf', 2011),
(44, 'FEJ', 'Tema Teoría', 2, '(1)', 'documentos/44.pdf', 2011),
(45, 'FEJ', 'Tema Teoría', 2, '(1)', 'documentos/45.pdf', 2011),
(46, 'FEJ', 'Tema Teoría', 2, '(3)', 'documentos/46.pdf', 2011),
(47, 'FEJ', 'Tema Teoría', 2, '(4)', 'documentos/47.pdf', 2011),
(48, 'FEJ', 'Tema Teoría', 1, '(2)', 'documentos/48.pdf', 2011),
(49, 'FEJ', 'Tema Teoría', 2, '(5)', 'documentos/49.pdf', 2011),
(50, 'FEJ', 'Tema Teoría', 3, '', 'documentos/50.pdf', 2011),
(51, 'IU', 'Tema Práctica', 2, 'HTML y PHP', 'documentos/51.zip', 2012),
(52, 'LPR', 'Tema Teoría', 0, '', 'documentos/52.pps', 2012),
(53, 'BD II', 'Tema Teoría', 1, 'Diseño Físico de una BD', 'documentos/53.pdf', 2012),
(54, 'BD II', 'Tema Práctica', 2, 'Arquitectura Física', 'documentos/54.pdf', 2012),
(55, 'RC II', 'Tema Teoría', 1, 'Arquitecturas', 'documentos/55.pdf', 2012),
(56, 'BD II', 'Tema Práctica', 3, 'Instancia', 'documentos/56.pdf', 2012),
(57, 'RC II', 'Tema Teoría', 2, 'Medios de Transmisión y Topologías', 'documentos/57.pdf', 2012),
(58, 'LPR', 'Tema Práctica', 1, '', 'documentos/58.pdf', 2012),
(59, 'LPR', 'Tema Práctica', 2, '', 'documentos/59.pdf', 2012),
(60, 'LPR', 'Tema Práctica', 3, '', 'documentos/60.pdf', 2012),
(61, 'BD II', 'Tema Teoría', 1, 'Apuntes de Índices', 'documentos/61.pdf', 2012),
(62, 'LPR', 'Tema Teoría', 1, 'Programación Imperativa 1', 'documentos/62.pdf', 2012),
(63, 'LPR', 'Tema Teoría', 1, 'Programación Imperativa 2', 'documentos/63.pdf', 2012),
(65, 'LPR', 'Tema Práctica', 4, '', 'documentos/65.pdf', 2012),
(66, 'BD II', 'Tema Práctica', 4, 'Diseño Conceptual y Lógico', 'documentos/66.pdf', 2012),
(67, 'BD II', 'Tema Práctica', 5, 'DLL', 'documentos/67.pdf', 2012),
(68, 'BD II', 'Tema Práctica', 5, 'Vistas', 'documentos/68.pdf', 2012),
(69, 'BD II', 'Tema Práctica', 6, 'PLSQL', 'documentos/69.pdf', 2012),
(70, 'BD II', 'Tema Práctica', 7, 'Triggers', 'documentos/70.pdf', 2012),
(71, 'BD II', 'Tema Teoría', 3, 'Transacciones 1', 'documentos/71.pdf', 2012),
(72, 'BD II', 'Tema Teoría', 3, 'Transacciones 2', 'documentos/72.pdf', 2012),
(73, 'BD II', 'Tema Teoría', 4, 'Concurrencia en SQL', 'documentos/73.pdf', 2012),
(74, 'BD II', 'Tema Teoría', 4, 'Control de Concurrencia', 'documentos/74.pdf', 2012),
(75, 'RC II', 'Tema Teoría', 3, 'Internet', 'documentos/75.pdf', 2012),
(76, 'RC II', 'Tema Teoría', 5, 'NAT Proxy', 'documentos/76.pdf', 2012),
(77, 'RC II', 'Tema Teoría', 6, 'Tecnologías Núcleo', 'documentos/77.pdf', 2012),
(78, 'RC II', 'Tema Teoría', 4, 'Redes de Acceso', 'documentos/78.pdf', 2012),
(79, 'LPR', 'Tema Práctica', 6, 'Parte 1', '', 2012),
(80, 'LPR', 'Tema Práctica', 5, '', 'documentos/80.pdf', 2012),
(81, 'LPR', 'Tema Práctica', 6, 'Parte 2', 'documentos/81.pdf', 2012),
(82, 'LPR', 'Tema Teoría', 1, 'Programación Imperativa 3', 'documentos/82.zip', 2012),
(106, 'CDA', 'Tema Teoría', 1, 'Redes SAN y elementos de un SAN', 'documentos/106.pdf', 2012),
(105, 'CDA', 'Tema Teoría', 0, 'Introducción al CPD', 'documentos/105.pdf', 2012),
(143, 'CDI', 'Tema Teoría', 0, 'Apuntes (Finales)', 'documentos/143.pdf', 2012),
(115, 'SI', 'Tema Teoría', 2, 'Representación del Conocimiento 2', 'documentos/115.pdf', 2012),
(114, 'SI', 'Tema Teoría', 2, 'Representación del Conocimiento 1', 'documentos/114.pdf', 2012),
(89, 'SO II', 'Tema Teoría', 1, 'Instalación de Linux', 'documentos/89.pdf', 2012),
(90, 'SO II', 'Tema Teoría', 1, 'Fundamentos de Linux', 'documentos/90.pdf', 2012),
(91, 'IS II', 'Tema Teoría', 1, 'Introducción', 'documentos/91.pdf', 2012),
(92, 'IS II', 'Tema Teoría', 2, 'Procesos Complejos', 'documentos/92.pdf', 2012),
(93, 'SO II', 'Tema Teoría', 2, 'El Sistema de Archivos', 'documentos/93.pdf', 2012),
(95, 'PL', 'Tema Teoría', 1, 'Introducción', 'documentos/95.pdf', 2012),
(102, 'PL', 'Tema Teoría', 2, 'Análisis Léxico', 'documentos/102.pdf', 2012),
(97, 'SO II', 'Tema Teoría', 3, 'Arranque', 'documentos/97.pdf', 2012),
(98, 'IS II', 'Tema Teoría', 3, 'Procesos Ligeros', 'documentos/98.pdf', 2012),
(113, 'SI', 'Tema Teoría', 1, 'Introducción a la Inteligencia Artificial', 'documentos/113.pdf', 2012),
(100, 'IS II', 'Tema Teoría', 4, 'Diseño Arquitectónico', 'documentos/100.pdf', 2012),
(112, 'SI', 'Tema Teoría', 3, 'Búsquedas 2', 'documentos/112.pdf', 2012),
(103, 'PL', 'Tema Teoría', 3, 'Análisis Sintáctico 1 - Introducción', 'documentos/103.pdf', 2012),
(104, 'SO II', 'Tema Teoría', 4, 'Scripting', 'documentos/104.pdf', 2012),
(107, 'CDA', 'Tema Teoría', 2, 'Tecnologías de Centros de Datos', 'documentos/107.pdf', 2012),
(111, 'SI', 'Tema Teoría', 3, 'Búsquedas 1', 'documentos/111.pdf', 2012),
(109, 'DGP', 'Tema Teoría', 1, 'Introducción (Hecho por OGSN)', 'documentos/109.pdf', 2012),
(110, 'SO II', 'Tema Teoría', 5, 'tr, sed y expresiones regulares', 'documentos/110.pdf', 2012),
(116, 'SI', 'Tema Teoría', 2, 'Representación del Conocimiento 3', 'documentos/116.pdf', 2012),
(117, 'PL', 'Tema Teoría', 3, 'Análisis Sintáctico 2 - Gramáticas Libres de Contexto', 'documentos/117.pdf', 2012),
(118, 'SO II', 'Tema Teoría', 6, 'cut, paste y awk', 'documentos/118.pdf', 2012),
(119, 'SI', 'Tema Teoría', 4, 'Agentes', 'documentos/119.pdf', 2012),
(120, 'PL', 'Tema Teoría', 3, 'Análisis Sintáctico 3 - Descendente', 'documentos/120.pdf', 2012),
(126, 'IS II', 'Tema Teoría', 5, 'Diseño Detallado', 'documentos/126.pdf', 2012),
(125, 'SO II', 'Tema Teoría', 7, 'Autotools Short', 'documentos/125.pdf', 2012),
(124, 'SO II', 'Tema Teoría', 7, 'Autotools', 'documentos/124.pdf', 2012),
(127, 'IS II', 'Tema Teoría', 6, 'Patrones de Diseño', 'documentos/127.pdf', 2012),
(135, 'PL', 'Tema Teoría', 3, 'Algoritmos de Análisis Sintáctico', 'documentos/135.pdf', 2012),
(129, 'SO II', 'Tema Teoría', 8, 'kernel', 'documentos/129.zip', 2012),
(136, 'DGP', 'Tema Teoría', 2, 'PmBok (Hecho por TroncoBlog y Timy C.)', 'documentos/136.pdf', 2012),
(132, 'PL', 'Tema Teoría', 3, 'Análisis Sintáctico 4 - Ascendente 1', 'documentos/132.pdf', 2012),
(133, 'PL', 'Tema Teoría', 3, 'Análisis Sintáctico 4 - Ascendente 2', 'documentos/133.pdf', 2012),
(134, 'PL', 'Tema Teoría', 4, 'Análisis Semántico', 'documentos/134.pdf', 2012),
(138, 'IS II', 'Tema Teoría', 7, 'Pruebas', 'documentos/138.pdf', 2012),
(139, 'IS II', 'Tema Teoría', 8, 'Reutilización', 'documentos/139.pdf', 2012),
(141, 'CDA', 'Tema Teoría', 3, 'Virtualización 2 - Caso Práctico', 'documentos/141.pdf', 2012),
(142, 'CDA', 'Tema Teoría', 3, 'Virtualización 1 - Presentación', 'documentos/142.pdf', 2012);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudio`
--

CREATE TABLE IF NOT EXISTS `estudio` (
  `nombreUsuario` varchar(50) NOT NULL,
  `idAsignatura` varchar(6) NOT NULL,
  `grupo` int(1) NOT NULL,
  PRIMARY KEY (`nombreUsuario`,`idAsignatura`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `examen`
--

CREATE TABLE IF NOT EXISTS `examen` (
  `idExamen` int(10) NOT NULL,
  `idAsignatura` varchar(6) NOT NULL,
  `tipoExamen` varchar(20) NOT NULL,
  `numeracion` int(2) DEFAULT NULL,
  `descripcion` varchar(500) DEFAULT NULL,
  `tipoGrupo` tinyint(1) NOT NULL,
  `fechaExamen` date DEFAULT NULL,
  `fechaExamenA` date DEFAULT NULL,
  `fechaExamenB` date DEFAULT NULL,
  `fechaExamenC` date DEFAULT NULL,
  `fechaExamenD` date DEFAULT NULL,
  `fechaExamenE` date DEFAULT NULL,
  `fechaExamenF` date DEFAULT NULL,
  `fechaExamenG` date DEFAULT NULL,
  `enlace` varchar(500) DEFAULT NULL,
  `curso` int(4) NOT NULL,
  PRIMARY KEY (`idExamen`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `examen`
--

INSERT INTO `examen` (`idExamen`, `idAsignatura`, `tipoExamen`, `numeracion`, `descripcion`, `tipoGrupo`, `fechaExamen`, `fechaExamenA`, `fechaExamenB`, `fechaExamenC`, `fechaExamenD`, `fechaExamenE`, `fechaExamenF`, `fechaExamenG`, `enlace`, `curso`) VALUES
(2, 'AC II', 'Final', 0, '', 1, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'examenes/2.pdf', 2011),
(3, 'AC I', 'Final', 0, '', 1, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'examenes/3.pdf', 2010),
(4, 'AL', 'Final', 0, '', 1, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'examenes/4.pdf', 2011),
(5, 'BD II', 'Práctica', 1, 'Control de las Prácticas 1, 2 y 3', 0, '2011-10-14', '2011-10-13', '2011-10-13', '2011-10-14', '2011-10-14', '0000-00-00', '0000-00-00', '0000-00-00', '', 2012),
(6, 'BD II', 'Parcial', 1, '', 1, '2011-11-07', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(7, 'LPR', 'Final', 0, '', 1, '2012-01-13', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(8, 'BD II', 'Parcial', 2, '', 1, '2012-01-09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(9, 'RC II', 'Final', 0, '', 1, '2012-01-20', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(12, 'LPR', 'Test', 1, '', 1, '2011-11-24', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(11, 'HAE', 'Final', 0, '', 1, '2012-01-18', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', 2012),
(13, 'LPR', 'Test', 2, '', 1, '2011-12-01', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(14, 'LPR', 'Test', 3, '', 1, '2011-12-22', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(15, 'PL', 'Prueba', 1, 'Introducción y Análisis Léxico', 1, '2012-03-01', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', 2012),
(16, 'PL', 'Prueba', 2, 'Análisis Sintáctico', 1, '2012-04-19', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', 2012),
(17, 'PL', 'Prueba', 3, 'Análisis Semántico', 0, '2012-05-07', '2012-05-07', '2012-05-04', '2012-05-07', '2012-05-07', '0000-00-00', '0000-00-00', '0000-00-00', '', 2012),
(19, 'PL', 'Final', 0, '', 1, '2012-05-28', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', 2012),
(20, 'SI', 'Prueba', 1, '', 1, '2012-03-23', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(21, 'SI', 'Práctica', 1, '', 0, '2012-03-28', '2012-03-27', '2012-03-27', '2012-03-28', '2012-03-27', '0000-00-00', '0000-00-00', '0000-00-00', '', 2012),
(22, 'CDI', 'Final', 0, '', 1, '2012-06-01', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(23, 'CDA', 'Final', 0, '', 1, '2012-05-23', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(24, 'IS II', 'Final', 0, '', 1, '2012-05-25', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(25, 'IS II', 'Parcial', 1, '', 1, '2012-03-14', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(26, 'IS II', 'Parcial', 2, '', 1, '2012-05-16', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(27, 'DGP', 'Final', 0, '', 1, '2012-05-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(28, 'DGP', 'Parcial', 1, 'Introducción', 1, '2012-03-07', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(29, 'DGP', 'Parcial', 2, 'PmBok', 1, '2012-04-25', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(30, 'DGP', 'Parcial', 3, 'Scrum', 1, '2012-05-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(31, 'SO II', 'Final', 0, '', 1, '2012-06-01', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(32, 'SI', 'Final', 0, '', 1, '2012-05-30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(33, 'CDI', 'Práctica', 1, '', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', 2012),
(34, 'CDI', 'Práctica', 2, '', 0, '2012-05-10', '2012-05-09', '2012-05-09', '2012-05-10', '2012-05-10', '0000-00-00', '0000-00-00', '0000-00-00', '', 2012);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesor`
--

CREATE TABLE IF NOT EXISTS `profesor` (
  `idProfesor` int(2) NOT NULL,
  `nombreProfesor` varchar(50) NOT NULL,
  `despacho` varchar(50) NOT NULL,
  `telefono` varchar(30) NOT NULL,
  `correoElectronico` varchar(50) NOT NULL,
  `tutorias1` varchar(500) NOT NULL,
  `tutorias2` varchar(500) NOT NULL,
  `tutorias3` varchar(500) NOT NULL,
  PRIMARY KEY (`idProfesor`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `profesor`
--

INSERT INTO `profesor` (`idProfesor`, `nombreProfesor`, `despacho`, `telefono`, `correoElectronico`, `tutorias1`, `tutorias2`, `tutorias3`) VALUES
(1, 'José Manuel Camba Sánchez', '31 - Ed. Física', '988 38 70 17', 'jcamba@uvigo.es', 'Miércoles de 10:00 a 11:00 y Vienres de 16:00 a 19:00', 'N.D.', 'N.D.'),
(2, 'Marta Pérez Rodríguez', '28 - Ed. Física', '988 38 72 37', 'martapr@uvigo.es', 'Jueves de 16:00 a 17:00', 'Miércoles de 12:30 a 13:30', 'Martes de 12:30 a 13:30'),
(3, 'Agustín Seoane González', '30 - Ed. Física', '988 38 72 31', 'asg@uvigo.es', 'Miércoles de 19:15 a 21:45', 'Miércoles de 17:00 a 19:30', 'Miércoles de 17:00 a 19:30'),
(4, 'Ana Garriga Domínguez', '414 o 24 - 4ª Planta, Ed. Xurídico-Empresarial', '988 36 89 11 o 988 36 88 34', 'agarriga@uvigo.es', 'Martes de 11:00 a 14:00 y de 16:30 a 18:00 y Miércoles de 16:30 a 18:00', 'Lunes de 12:00 a 14:00, Miércoles de 12:00 a 14:00 y Viernes de 12:00 a 14:00', 'Lunes de 11:00 a 14:00 y Miércoles de 11:00 a 14:00'),
(5, 'Pilar Isabel Carrión Pardo', '409', '988 38 70 16', 'pcarrion@uvigo.es', 'Lunes de 09:00 a 11:00 y de 16:00 a 18:00 y Miércoles de 09:00 a 11:00', 'Miércoles de 10:00 a 13:00 y Jueves de 10:00 a 13:00', 'Miércoles de 10:00 a 13:00 y Jueves de 10:00 a 13:00'),
(6, 'María Lourdes Borrajo Diz', '307', '988 38 70 28', 'lborrajo@uvigo.es', 'Lunes de 10:00 a 11:00, Martes de 10:00 a 11:00 y de 16:00 a 16:30, Miércoles de 10:00 a 12:00 y de 16:00 a 16:30 y Jueves de 11:30 a 12:30', 'Martes de 10:00 a 12:00, Miércoles de 10:00 a 12:00 y Jueves de 10:00 a 12:00', 'Martes de 10:00 a 13:00 y Miércoles de 12:00 a 13:00'),
(7, 'Carlos Castro Miguens', '312', '988 38 70 23', 'cmiguens@uvigo.es', 'Lunes de 14:00 a 15:00, Miércoles de 10:00 a 11:00 y de 14:00 a 15:00 y Jueves de 10:00 a 11:30', 'Lunes de 09:00 a 10:30 y Martes de 09:00 a 12:00', 'Lunes de 10:00 a 14:30'),
(8, 'Marcos Pérez Suárez', '313', '988 38 70 23', 'marcsps@movistar.es', 'Miércoles de 18:00 a 21:00', 'Miércoles de 18:00 a 21:00', 'Miércoles de 18:00 a 21:00'),
(9, 'Matías García Rivera', '311', '988 38 70 35', 'mgrivera@uvigo.es', 'Miércoles de 11:00 a 14:00 y Jueves de 11:00 a 14:00', 'Lunes de 13:30 a 15:00, Martes de 13:30 a 15:00 y Viernes de 09:00 a 10:30 y de 13:30 a 15:00', 'Miércoles de 09:00 a 15:00'),
(10, 'Manuel Míguez Nóvoa', '311', '988 38 70 35', 'miguez@uvigo.es', 'Lunes de 19:00 a 21:00 y Martes de 12:30 a 13:00', 'Martes de 19:00 a 21:30', 'Martes de 16:30 a 19:00'),
(11, 'Máximo Sotelo García', '310', '988 38 70 34', 'msotelo@uvigo.es', 'Lunes de 19:00 a 21:00 y Jueves de 14:00 a 14:30', 'Martes de 19:00 a 21:30', 'Martes de 16:30 a 19:00'),
(12, 'Rosalía Laza Fidalgo', '406', '988 38 70 13', 'rlaza@uvigo.es', 'Lunes de 10:00 a 13:00 y Jueves de 10:00 a 13:00', 'Martes de 10:00 a 13:00 y Viernes de 10:00 a 13:00', 'Martes de 10:00 a 13:00 y Miércoles de 10:00 a 13:00'),
(13, 'María Reyes Pavón Rial', '406', '988 38 70 13', 'pavon@uvigo.es', 'Martes de 10:00 a 13:00 y Miércoles de 12:00 a 14:00', 'Martes de 10:00 a 13:00 y Miércoles de 12:00 a 14:00', 'Martes de 10:00 a 13:00 y Miércoles de 12:00 a 14:00'),
(14, 'Florentino Fernández Riverola', '408', '988 38 70 15', 'riverola@uvigo.es', 'Viernes de 09:00 a 13:00 y de 16:00 a 18:00', 'Viernes de 09:00 a 13:00 y de 16:00 a 18:00', 'Viernes de 09:00 a 13:00 y de 16:00 a 18:00'),
(15, 'Francisco Javier García Cutrín', 'N.D.', 'N.D.', 'N.D.', 'N.D.', 'N.D.', 'N.D.'),
(16, 'Enrique Barreiro Alonso', '414', '988 36 89 11', 'enrique@uvigo.es', 'Lunes de 11:00 a 13:00 y de 16:00 a 17:00', 'Lunes de 11:00 a 13:00 y de 16:00 a 17:00', 'Lunes de 11:00 a 14:00'),
(17, 'Susana Gómez Carnero', '413', '988 38 70 20', 'susanagomez@uvigo.es', 'Miércoles de 19:00 a 21:00 y Jueves de 19:00 a 21:00', 'Martes de 17:00 a 21:00', 'Miércoles de 17:00 a 19:00 y Jueves de 17:00 a 19:00'),
(18, 'María José Lado Touriño', '405', '988 38 70 12', 'mrpepa@uvigo.es', 'Martes de 10:00 a 12:00 y Miércoles de 10:00 a 12:00', 'Lunes de 12:30 a 13:30, Martes de 12:30 a 13:30 y Miércoles de 16:30 a 18:30', 'Martes de 10:00 a 12:00 y Miércoles de 10:00 a 12:00'),
(19, 'José Baltasar García Pérez-Schofield', '307', '988 36 88 91', 'jgarcia@ei.uvigo.es', 'Miércoles de 12:00 a 14:00 y Viernes de 10:00 a 14:00', 'Miércoles de 10:00 a 11:00, Jueves de 10:00 a 11:00 y Viernes de 10:00 a 14:00', 'Miércoles de 12:00 a 14:00 y Viernes de 11:00 a 14:00'),
(20, 'María Encarnación Gonzalez Rufino', '409', '988 38 70 16', 'nrufino@uvigo.es', 'Lunes de 15:00 a 17:00, Miércoles de 10:00 a 11:30 y de 15:30 a 17:00 y Viernes de 16:00 a 17:00', 'Lunes de 15:30 a 18:30, Miércoles de 10:00 a 11:30 y Jueves de 10:00 a 11:30', 'Martes de 09:30 a 12:30 y Miércoles de 09:30 a 12:30'),
(21, 'Pedro Cuesta Morales', '411', '988 38 70 18', 'pcuesta@uvigo.es', 'Martes de 10:00 a 12:00, Miércoles de 10:00 a 12:00 y Jueves de 10:00 a 12:00', 'Martes de 10:00 a 12:00, Miércoles de 10:00 a 12:00 y Jueves de 10:00 a 12:00', 'Miércoles de 11:00 a 14:00 y de 16:00 a 19:00'),
(22, 'Emilio García Roselló', '308', '988 38 70 29', 'erosello@uvigo.es', 'Lunes de 10:00 a 12:00 y de 14:00 a 16:00 y Martes de 10:00 a 12:00', 'Miércoles de 09:00 a 15:00', 'Miércoles de 09:00 a 15:00'),
(23, 'Tomás Raimundo Cotos Yáñez', '12 - 5ª Planta, Ed. Xurídico-Empresarial', '988 36 87 66', 'cotos@uvigo.es', 'Lunes de 16:00 a 19:00, Jueves de 10:00 a 11:30 y Viernes de 10:00 a 11:30', 'Martes de 16:00 a 18:00, Jueves de 16:00 a 18:00 y Viernes de 10:00 a 12:00', 'Martes de 10:00 a 13:00 y Miércoles de 10:00 a 13:00'),
(24, 'José Luis Barros Justo', '308', '988 38 70 29', 'jbarros@uvigo.es', 'Martes de 09:00 a 12:00 y Miércoles de 09:00 a 12:00', 'Viernes de 09:00 a 15:00', 'Viernes de 09:00 a 15:00'),
(25, 'José Manuel Sotelo Martínez', '310', '988 38 70 34', 'jmsotelo@uvigo.es', 'Lunes de 20:00 a 22:00 y Martes de 20:00 a 22:00', 'Lunes de 20:00 a 22:00 y Martes de 20:00 a 22:00', 'Lunes de 17:00 a 19:00 y Martes de 17:00 a 19:00'),
(26, 'Juan Francisco Gálvez Gálvez', '402', '988 38 70 09', 'galvez@uvigo.es', 'Lunes de 10:00 a 14:00', 'Lunes de 10:00 a 14:00', 'Lunes de 10:00 a 14:00'),
(27, 'Arturo José Méndez Penín', '404', '988 38 70 11', 'mrarthur@uvigo.es', 'Martes de 10:00 a 13:00 y Miércoles de 10:00 a 13:00', 'Jueves de 16:30 a 19:30 y Viernes de 10:00 a 13:00', 'Martes de 10:00 a 13:00 y Miércoles de 10:00 a 13:00'),
(28, 'Silvana Gómez Meire', '410', '988 38 70 17', 'sgmeire@ei.uvigo.es', 'Martes de 11:00 a 13:00 y de 17:00 a 19:00 y Miércoles de 11:00 a 13:00', 'Lunes de 11:00 a 13:00 y de 16:30 a 18:30 y Miércoles de 16:30 a 18:30', 'Martes de 11:00 a 13:00, Miércoles de 11:00 a 13:00 y Jueves de 11:00 a 13:00'),
(29, 'Xosé Antón Vila Sobrino', '309', '988 38 70 30', 'anton@uvigo.es', 'Martes de 10:00 a 14:00', 'Martes de 10:00 a 14:00', 'Martes de 10:00 a 14:00'),
(30, 'José Ramón Méndez Reboredo', '408', '988 38 70 15', 'moncho.mendez@sing.ei.uvigo.es', 'Viernes de 10:00 a 14:00 y de 16:00 a 18:00', 'Miércoles de 16:00 a 19:00 y Jueves de 16:00 a 19:00', 'Viernes de 10:00 a 14:00 y de 16:00 a 18:00'),
(31, 'Eva María Lorenzo Iglesias', '412', '988 38 70 19', 'eva@uvigo.es', 'Miércoles de 12:00 a 14:00 y Viernes de 12:00 a 14:00', 'Miércoles de 12:00 a 14:00 y Viernes de 12:00 a 14:00', 'Miércoles de 12:00 a 14:00 y Viernes de 12:00 a 14:00'),
(32, 'Moisés Cid Deza', '412', '988 38 70 19', 'moises@uvigo.es', 'Jueves de 11:00 a 15:00', 'Viernes de 09:00 a 10:30 y de 12:00 a 14:30', 'Miércoles de 09:00 a 13:00'),
(33, 'Daniel González Peña', '408', '988 38 70 15', 'dgpena@uvigo.es', 'Lunes de 12:00 a 14:00 y Viernes de 16:00 a 20:00', 'Lunes de 12:00 a 14:00 y Viernes de 16:00 a 20:00', 'Viernes de 10:00 a 14:00 y de 16:00 a 18:00'),
(34, 'José Manuel Sorribes Fernández', '412', '988 38 70 19', 'sorribes@uvigo.es', 'Martes de 16:00 a 18:00 y Miércoles de 12:00 a 14:00', 'Jueves de 16:00 a 20:00', 'Jueves de 15:00 a 19:00'),
(35, 'Javier Rodeiro Iglesias', '413', '988 38 70 20', 'jriglesias@correo.ei.uvigo.es', 'Lunes de 17:00 a 19:00, Martes de 16:00 a 18:00 y Miércoles de 10:00 a 12:00', 'Martes de 10:00 a 12:00 y Jueves de 09:00 a 13:00', 'Jueves de 10:00 a 13:00 y de 16:00 a 19:00'),
(36, 'José Ayude Vázquez', '405', '988 38 70 12', 'jayude@uvigo.es', 'Jueves de 09:00 a 12:00', 'Viernes de 10:00 a 13:00', 'Viernes de 10:00 a 13:00'),
(37, 'Leandro Rodríguez Liñares', '402', '988 38 70 09', 'leandro@uvigo.es', 'Jueves de 09:00 a 12:00, de 14:00 a 16:00 y de 20:00 a 21:00', 'Miércoles de 09:30 a 12:00 y de 14:30 a 16:00', 'Lunes de 09:30 a 13:30'),
(38, 'Miguel Ramón Díaz-Cacho Medina', '310', '988 38 70 34', 'mcacho@uvigo.es', 'Martes de 11:00 a 13:00 y de 16:00 a 18:00', 'Martes de 12:00 a 14:00 y Viernes de 15:00 a 17:00', 'Miércoles de 12:00 a 14:00 y de 16:00 a 18:00'),
(39, 'Francisco Javier Rodríguez Martínez', '301', '988 38 70 22', 'franjrm@uvigo.es', 'Martes de 09:00 a 10:00 y de 16:00 a 19:00', 'Viernes de 10:00 a 14:00', 'Viernes de 10:00 a 14:00'),
(40, 'David Nicholas Olivieri Cecchi', '305', '988 38 70 26', 'olivieri@ei.uvigo.es', 'Lunes de 10:00 a 12:00, Miércoles de 10:00 a 12:00 y Jueves de 12:00 a 14:00', 'Miércoles de 10:00 a 14:00 y Jueves de 12:00 a 14:00', 'Miércoles de 10:00 a 14:00 y Jueves de 12:00 a 14:00'),
(41, 'Arno Formella', '309', '988 38 70 30', 'formella@ei.uvigo.es', 'Lunes de 10:00 a 13:00 y de 17:00 a 20:00', 'Lunes de 10:00 a 13:00 y de 17:00 a 20:00', 'Lunes de 10:00 a 13:00 y de 16:00 a 19:00'),
(42, 'Celso Campos Bastos', '410', '988 38 70 17', 'ccampos@uvigo.es', 'Martes de 12:00 a 14:00 y de 17:00 a 19:00 y Jueves de 17:00 a 19:00', 'Martes de 09:00 a 11:00 y de 12:00 a 14:00 y Jueves de 17:00 a 19:00', 'Martes de 10:00 a 14:00 y Jueves de 12:00 a 14:00'),
(43, 'Jacinto González Dacosta', 'N.D.', 'N.D.', 'N.D.', 'N.D.', 'N.D.', 'N.D.'),
(44, 'Juan Carlos González Moreno', '407', '988 38 70 14', 'jcmoreno@uvigo.es', 'Martes de 09:00 a 11:30, Jueves de 09:00 a 11:30 y Viernes de 12:00 a 14:00', 'Martes de 10:00 a 13:00 y Miércoles de 10:00 a 13:00', 'Martes de 10:00 a 13:00 y Miércoles de 10:00 a 13:00'),
(45, 'David Gelpi Fleta', '305', '988 38 70 26', 'davidg@uvigo.es', 'Lunes de 16:00 a 18:00 y Viernes de 11:30 a 12:00', 'Viernes de 11:30 a 14:00', 'Martes de 11:30 a 13:30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarea`
--

CREATE TABLE IF NOT EXISTS `tarea` (
  `idTarea` int(10) NOT NULL,
  `idAsignatura` varchar(6) NOT NULL,
  `tipoTarea` varchar(20) NOT NULL,
  `numeracion` int(2) DEFAULT NULL,
  `descripcion` varchar(1000) DEFAULT NULL,
  `tipoGrupo` tinyint(1) NOT NULL,
  `fechaEntrega` date DEFAULT NULL,
  `fechaEntregaA` date DEFAULT NULL,
  `fechaEntregaB` date DEFAULT NULL,
  `fechaEntregaC` date DEFAULT NULL,
  `fechaEntregaD` date DEFAULT NULL,
  `fechaEntregaE` date DEFAULT NULL,
  `fechaEntregaF` date DEFAULT NULL,
  `fechaEntregaG` date DEFAULT NULL,
  `enlace` varchar(500) DEFAULT NULL,
  `curso` int(4) NOT NULL,
  PRIMARY KEY (`idTarea`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tarea`
--

INSERT INTO `tarea` (`idTarea`, `idAsignatura`, `tipoTarea`, `numeracion`, `descripcion`, `tipoGrupo`, `fechaEntrega`, `fechaEntregaA`, `fechaEntregaB`, `fechaEntregaC`, `fechaEntregaD`, `fechaEntregaE`, `fechaEntregaF`, `fechaEntregaG`, `enlace`, `curso`) VALUES
(2, 'AC II', 'Ejercicio', 1, '', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/2.pdf', 2011),
(3, 'AC II', 'Práctica', 1, 'Mediano (Primer Conjunto)', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/3.pdf', 2011),
(4, 'AC II', 'Práctica', 2, 'Mediano (Segundo Conjunto)', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/4.pdf', 2011),
(5, 'AC II', 'Actividad', 1, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/5.pdf', 2011),
(6, 'AC II', 'Actividad', 2, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/6.pdf', 2011),
(7, 'AC II', 'Actividad', 3, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/7.pdf', 2011),
(8, 'AC II', 'Actividad', 4, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/8.pdf', 2011),
(9, 'AC II', 'Actividad', 5, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/9.pdf', 2011),
(10, 'AC II', 'Actividad', 6, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/10.pdf', 2011),
(11, 'AC II', 'Actividad', 7, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/11.pdf', 2011),
(12, 'AC II', 'Actividad', 8, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/12.pdf', 2011),
(13, 'AC II', 'Proyecto', 0, '', 1, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tareas/13.doc', 2011),
(14, 'AC I', 'Práctica', 0, 'Grupos Intermedios (Todos)', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/14.pdf', 2010),
(15, 'AC I', 'Actividad', 1, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/15.pdf', 2010),
(16, 'AC I', 'Actividad', 2, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/16.pdf', 2010),
(17, 'AC I', 'Actividad', 3, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/17.pdf', 2010),
(18, 'AC I', 'Actividad', 4, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/18.pdf', 2010),
(19, 'AC I', 'Actividad', 5, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/19.pdf', 2010),
(20, 'AC I', 'Proyecto', 0, '', 1, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tareas/20.pdf', 2011),
(21, 'AC I', 'Práctica', 0, 'Grupos Intermedios (Todos)', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/21.pdf', 2011),
(22, 'AC I', 'Actividad', 1, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/22.pdf', 2011),
(23, 'AC I', 'Actividad', 2, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/23.pdf', 2011),
(24, 'AC I', 'Actividad', 3, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/24.pdf', 2011),
(25, 'AC I', 'Actividad', 4, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/25.pdf', 2011),
(26, 'AC I', 'Actividad', 5, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/26.pdf', 2011),
(27, 'AC I', 'Actividad', 6, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/27.pdf', 2011),
(28, 'AC I', 'Actividad', 7, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/28.pdf', 2011),
(29, 'AC I', 'Proyecto', 0, '', 1, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2010),
(30, 'AL', 'Práctica', 1, '', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/30.pdf', 2010),
(31, 'AL', 'Práctica', 2, '', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/31.pdf', 2010),
(33, 'AL', 'Práctica', 4, '', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/33.pdf', 2010),
(34, 'AL', 'Práctica', 3, '', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', 2010),
(35, 'AL', 'Actividad', 1, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/35.pdf', 2010),
(36, 'AL', 'Actividad', 2, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/36.pdf', 2010),
(37, 'AL', 'Actividad', 3, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/37.pdf', 2010),
(38, 'AL', 'Actividad', 4, 'Grupo Reducido', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/38.pdf', 2010),
(39, 'AL', 'Proyecto', 0, '', 1, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tareas/39.doc', 2011),
(40, 'AL', 'Práctica', 1, '', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/40.pdf', 2011),
(41, 'AL', 'Práctica', 2, '', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/41.pdf', 2011),
(42, 'AL', 'Práctica', 3, '', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/42.doc', 2011),
(43, 'AL', 'Proyecto', 0, '', 1, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2010),
(44, 'BD II', 'Actividad', 1, 'Sistemas de Almacenamiento en Disco', 1, '2011-09-12', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/44.pdf', 2012),
(46, 'IU', 'Actividad', 1, 'ET1', 1, '2011-09-11', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/46.doc', 2012),
(96, 'IU', 'Actividad', 5, 'EP3', 1, '2011-11-08', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', 2012),
(47, 'FEJ', 'Práctica', 1, '', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/47.docx', 2011),
(48, 'FEJ', 'Práctica', 2, '', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/48.docx', 2011),
(49, 'FEJ', 'Práctica', 3, '', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/49.docx', 2011),
(50, 'FEJ', 'Práctica', 4, '', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/50.docx', 2011),
(51, 'FEJ', 'Práctica', 5, '', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/51.docx', 2011),
(52, 'FEJ', 'Práctica', 6, '', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/52.docx', 2011),
(53, 'HAE', 'Tarea', 1, '', 1, '2011-09-21', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/53.pdf', 2012),
(54, 'HAE', 'Práctica', 1, '', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/54.pdf', 2012),
(55, 'HAE', 'Práctica', 2, '', 0, '2011-09-13', '2011-09-12', '2011-09-12', '2011-09-13', '2011-09-13', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/55.pdf', 2012),
(56, 'RC II', 'Práctica', 1, 'Cableado Estructurado', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/56.pdf', 2012),
(58, 'BD II', 'Práctica', 1, 'Arquitectura Lógica', 0, '2011-09-23', '2011-09-22', '2011-09-22', '2011-09-23', '2011-09-23', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/58.pdf', 2012),
(59, 'HAE', 'Práctica', 4, '', 0, '2011-09-20', '2011-09-19', '2011-09-19', '2011-09-20', '2011-09-20', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/59.pdf', 2012),
(60, 'IU', 'Ejercicio', 1, 'HTML y PHP', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/60.odt', 2012),
(61, 'BD II', 'Actividad', 2, 'Técnicas de dispersión con expansión dinámica del fichero', 1, '2011-09-19', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tareas/61.pdf', 2012),
(62, 'LPR', 'Práctica', 1, '', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/62.pdf', 2012),
(63, 'RC II', 'Práctica', 2, 'TCP IP', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/63.pdf', 2012),
(64, 'BD II', 'Actividad', 3, 'Conceptos de Índices', 1, '2011-09-26', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tareas/64.pdf', 2012),
(65, 'IU', 'Actividad', 2, 'EP1', 1, '2011-09-27', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/65.zip', 2012),
(66, 'HAE', 'Práctica', 6, '', 0, '2011-09-27', '2011-09-26', '2011-09-26', '2011-09-27', '2011-09-27', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/66.pdf', 2012),
(67, 'BD II', 'Práctica', 2, 'Arquitectura Física', 0, '2011-09-30', '2011-09-29', '2011-09-29', '2011-09-30', '2011-09-30', '0000-00-00', '0000-00-00', '0000-00-00', '', 2012),
(68, 'LPR', 'Práctica', 2, '', 0, '2011-10-13', '2011-10-13', '2011-10-13', '2011-10-09', '2011-10-09', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/68.pdf', 2012),
(69, 'HAE', 'Tarea', 2, '', 1, '2011-10-17', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/69.pdf', 2012),
(70, 'RC II', 'Práctica', 3, 'Wireless', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/70.pdf', 2012),
(71, 'RC II', 'Práctica', 3, 'Wireless WDS', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/71.pdf', 2012),
(72, 'RC II', 'Práctica', 4, 'Routing', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/72.pdf', 2012),
(73, 'RC II', 'Práctica', 5, 'Firewall', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/73.pdf', 2012),
(74, 'RC II', 'Práctica', 6, 'Bonding', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/74.pdf', 2012),
(75, 'HAE', 'Práctica', 8, '', 0, '2011-10-04', '2011-10-03', '2011-10-03', '2011-10-04', '2011-10-04', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/75.pdf', 2012),
(76, 'BD II', 'Actividad', 4, 'Ejemplos Simples de Índices', 1, '2011-10-03', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tareas/76.pdf', 2012),
(77, 'BD II', 'Práctica', 3, 'Instancia', 0, '2011-10-07', '2011-10-06', '2011-10-06', '2011-10-07', '2011-10-07', '0000-00-00', '0000-00-00', '0000-00-00', '', 2012),
(78, 'FEJ', 'Proyecto', 0, '', 1, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2011),
(79, 'FEJ', 'Proyecto', 0, '', 1, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2010),
(80, 'IU', 'Ejercicio', 2, 'Aplicación de CSS y validación de formularios', 1, '2011-10-11', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/80.pdf', 2012),
(81, 'HAE', 'Práctica', 9, '', 0, '2011-10-11', '2011-10-10', '2011-10-10', '2011-10-11', '2011-10-11', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/81.pdf', 2012),
(83, 'BD II', 'Actividad', 4, 'Ejemplos de Índices 2', 1, '2011-10-10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tareas/83.pdf', 2012),
(84, 'BD II', 'Práctica', 3, 'Control de la BD', 0, '2011-10-14', '2011-10-13', '2011-10-13', '2011-10-14', '2011-10-14', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/84.pdf', 2012),
(85, 'BD II', 'Práctica', 4, 'Ampliación del diseño conceptual y lógico', 0, '2011-10-21', '2011-10-20', '2011-10-20', '2011-10-21', '2011-10-21', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/85.pdf', 2012),
(86, 'LPR', 'Práctica', 3, '', 0, '2011-10-27', '2011-10-27', '2011-10-27', '2011-10-23', '2011-10-23', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/86.pdf', 2012),
(87, 'BD II', 'Actividad', 5, 'Ejercicios de Diseño Físico', 1, '2011-10-17', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tareas/87.pdf', 2012),
(88, 'IU', 'Actividad', 3, 'EP2', 1, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/88.pdf', 2012),
(89, 'BD II', 'Actividad', 6, 'Optimización de Consultas', 1, '2011-10-24', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tareas/89.pdf', 2012),
(90, 'HAE', 'Tarea', 3, '', 1, '2011-10-31', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tareas/90.pdf', 2012),
(91, 'LPR', 'Práctica', 4, '', 0, '2011-11-10', '2011-11-10', '2011-11-10', '2011-11-06', '2011-11-06', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/91.pdf', 2012),
(95, 'IU', 'Actividad', 4, 'ET2', 1, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/95.pdf', 2012),
(97, 'LPR', 'Proyecto', 2, '', 1, '2011-11-15', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(93, 'BD II', 'Práctica', 5, 'DDL', 0, '2011-11-18', '2011-11-10', '2011-11-10', '2011-11-18', '2011-11-18', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/93.pdf', 2012),
(94, 'LPR', 'Proyecto', 1, '', 1, '2011-10-27', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(98, 'LPR', 'Proyecto', 3, '', 1, '2011-12-13', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', 0),
(99, 'LPR', 'Práctica', 5, '', 0, '2011-12-01', '2011-12-01', '2011-12-01', '2011-11-20', '2011-11-20', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/99.pdf', 2012),
(100, 'HAE', 'Tarea', 4, '', 1, '2011-11-21', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/100.pdf', 2012),
(101, 'BD II', 'Actividad', 7, 'Conceptos de Transacciones', 1, '2011-11-14', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tareas/101.pdf', 2012),
(114, 'LPR', 'Práctica', 6, 'Parte 1', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/114.pdf', 2012),
(103, 'IU', 'Actividad', 6, 'ET4', 1, '2011-11-29', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/103.pdf', 2012),
(104, 'HAE', 'Práctica', 10, '', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/104.pdf', 2012),
(105, 'HAE', 'Práctica', 11, '', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/105.pdf', 2012),
(106, 'HAE', 'Tarea', 5, '', 1, '2011-12-12', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tareas/106.pdf', 2012),
(107, 'BD II', 'Práctica', 6, 'PL/SQL', 0, '2011-12-09', '2011-12-01', '2011-12-01', '2011-12-09', '2011-12-09', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/107.pdf', 2012),
(108, 'IU', 'Actividad', 7, 'ET5', 1, '2011-12-11', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tareas/108.pdf', 2012),
(109, 'HAE', 'Práctica', 16, '', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/109.pdf', 2012),
(110, 'BD II', 'Práctica', 7, 'Triggers', 0, '2011-12-22', '2011-12-22', '2011-12-22', '2011-12-22', '2011-12-22', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/110.pdf', 2012),
(111, 'HAE', 'Práctica', 17, 'Audio', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', 2012),
(112, 'HAE', 'Práctica', 18, 'FPGA', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', 2012),
(113, 'RC II', 'Práctica', 7, 'Nagios', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/113.pdf', 2012),
(115, 'LPR', 'Práctica', 6, 'Parte 2', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/115.pdf', 2012),
(116, 'LPR', 'Proyecto', 3, '', 1, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 2012),
(117, 'SI', 'Trabajo', 1, '	¿Qué son los sistemas inteligentes?', 1, '2012-03-03', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', 2012),
(118, 'SO II', 'Práctica', 1, 'Procesos', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/118.pdf', 2012),
(119, 'SO II', 'Práctica', 1, 'Sudo', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/119.pdf', 2012),
(120, 'IU', 'Actividad', 8, 'EP4', 1, '2012-01-27', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tareas/120.pdf', 2012),
(121, 'CDI', 'Práctica', 1, 'Introducción a la concurrencia en Java', 0, '2012-02-02', '2012-02-01', '2012-02-01', '2012-02-02', '2012-02-02', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/121.pdf', 2012),
(122, 'PL', 'Ejercicio', 1, 'Introducción (Calculadora)', 1, '2012-04-13', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/122.zip', 2012),
(123, 'DGP', 'Actividad', 1, 'Los proyectos en el siglo XXI', 0, '2012-02-03', '2012-02-02', '2012-02-02', '2012-02-03', '2012-02-03', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/123.mp3', 2012),
(124, 'CDA', 'Práctica', 1, 'Balanceo de cargas y alta disponibilidad', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/124.doc', 2012),
(125, 'SI', 'Práctica', 1, 'Lógica Proposicional', 0, '2012-02-06', '2012-02-06', '2012-02-06', '2012-02-06', '2012-02-06', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/125.zip', 2012),
(126, 'DGP', 'Práctica', 1, 'Diagrama de Gantt - Planificación del curso', 0, '2012-02-03', '2012-02-03', '2012-02-03', '2012-02-03', '2012-02-03', '0000-00-00', '0000-00-00', '0000-00-00', '', 2012),
(127, 'SO II', 'Práctica', 2, 'Sistemas de Archivos', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/127.pdf', 2012),
(128, 'SI', 'Práctica', 2, 'Lógica Predicados', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/128.zip', 2012),
(129, 'CDI', 'Práctica', 2, 'Parte A - Comunicación entre hilos', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/129.pdf', 2012),
(130, 'PL', 'Ejercicio', 2, 'Análisis Léxico', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/130.pdf', 2012),
(131, 'SO II', 'Práctica', 3, 'Arranque', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/131.pdf', 2012),
(132, 'CDA', 'Trabajo', 0, 'Proyecto de CDA', 1, '2012-05-04', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/132.pdf', 2012),
(133, 'CDI', 'Práctica', 2, 'Parte B - Multiplicar matrices con hilos', 0, '2012-02-23', '2012-02-22', '2012-02-22', '2012-02-23', '2012-02-23', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/133.pdf', 2012),
(134, 'PL', 'Ejercicio', 3, 'Autómatas Finitos', 1, '2012-04-13', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/134.zip', 2012),
(135, 'SI', 'Práctica', 3, 'Prolog', 1, '2012-03-11', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/135.zip', 2012),
(136, 'CDA', 'Práctica', 2, 'Coraid', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/136.doc', 2012),
(137, 'SO II', 'Práctica', 4, 'Scripting', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/137.pdf', 2012),
(138, 'CDI', 'Práctica', 3, 'Parte A - Sincronización de hilos', 0, '2012-03-08', '2012-03-07', '2012-03-07', '2012-03-08', '2012-03-08', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/138.pdf', 2012),
(139, 'PL', 'Ejercicio', 4, 'JFlex', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/139.pdf', 2012),
(140, 'SO II', 'Práctica', 5, 'tr, sed y expresiones regulares', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/140.pdf', 2012),
(141, 'CDI', 'Práctica', 3, 'Parte B - Patrón Productor-Consumidor', 0, '2012-03-15', '2012-03-14', '2012-03-14', '2012-03-15', '2012-03-15', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/141.pdf', 2012),
(150, 'SO II', 'Práctica', 7, 'Autotools', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/150.pdf', 2012),
(143, 'CDA', 'Práctica', 3, 'Firewalling y Socat', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/143.pdf', 2012),
(144, 'CDA', 'Práctica', 4, 'Cluster', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/144.pdf', 2012),
(145, 'SO II', 'Práctica', 6, 'cut, paste y awk', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/145.pdf', 2012),
(146, 'CDI', 'Práctica', 3, 'Parte C - Examen', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/146.pdf', 2012),
(147, 'DGP', 'Trabajo', 0, 'Proyecto de DGP', 1, '2012-05-21', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/147.zip', 2012),
(148, 'SI', 'Trabajo', 2, 'Conferencia Javier Bajo', 1, '2012-04-08', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/148.pdf', 2012),
(154, 'CDA', 'Práctica', 5, 'Qemu', 1, '2012-04-09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tareas/154.pdf', 2012),
(151, 'CDI', 'Práctica', 3, 'Parte D - java.util.concurrent', 1, '2012-04-09', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/151.pdf', 2012),
(152, 'PL', 'Ejercicio', 8, 'Lenguajes Mini', 1, '2012-05-28', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/152.zip', 2012),
(153, 'PL', 'Ejercicio', 5, 'Análisis Sintáctico', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/153.pdf', 2012),
(155, 'SO II', 'Práctica', 8, 'kernel', 1, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tareas/155.pdf', 2012),
(156, 'CDI', 'Práctica', 4, 'Parte A - Problemas de sincronización de hilos. Métodos de solución de conflictos.', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/156.pdf', 2012),
(157, 'CDI', 'Práctica', 4, 'Parte B - Problemas de sincronización de hilos. Métodos de solución de conflictos.', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/157.pdf', 2012),
(158, 'SI', 'Trabajo', 3, 'Resumen del Libro', 0, '2012-05-09', '2012-05-02', '2012-04-25', '2012-05-09', '2012-04-18', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/158.pdf', 2012),
(162, 'SO II', 'Práctica', 10, 'nc y socat', 1, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tareas/162.pdf', 2012),
(160, 'SO II', 'Práctica', 9, 'Redes', 1, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tareas/160.pdf', 2012),
(161, 'PL', 'Proyecto', 0, 'Proyecto de PL', 1, '2012-05-15', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', 2012),
(163, 'SI', 'Proyecto', 0, 'Proyecto de SI', 1, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', 2012),
(164, 'CDI', 'Práctica', 4, 'Parte C - Problemas de sincronización de hilos. Métodos de solución de conflictos.', 1, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tareas/164.pdf', 2012),
(165, 'PL', 'Ejercicio', 6, 'Análisis Sintáctico con CUP2', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/165.pdf', 2012),
(169, 'SO II', 'Práctica', 11, 'Firewalling', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/169.pdf', 2012),
(167, 'CDI', 'Práctica', 5, 'Parte A - Introducción a  la planificación de recursos en \r\nentornos concurrentes.', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/167.pdf', 2012),
(171, 'PL', 'Ejercicio', 7, 'Análisis Semántico', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/171.pdf', 2012),
(170, 'SO II', 'Práctica', 12, 'SSH', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/170.pdf', 2012),
(172, 'SO II', 'Práctica', 13, 'Redes Avanzadas 1', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/172.pdf', 2012),
(173, 'SO II', 'Práctica', 14, 'Redes Avanzadas 2', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/173.pdf', 2012),
(174, 'PL', 'Ejercicio', 9, 'Análisis Semántico con CUP2', 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 'tareas/174.pdf', 2012);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `nombreUsuario` varchar(50) NOT NULL,
  `contrasena` varchar(128) NOT NULL,
  `ultimaConexion` datetime NOT NULL,
  `correoElectronico` varchar(100) NOT NULL,
  `administrador` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`nombreUsuario`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`nombreUsuario`, `contrasena`, `ultimaConexion`, `correoElectronico`, `administrador`) VALUES
('prolsobrado', '70e27723383fd4385584e716e75021c14f046f94fe1b48151f78085b30bb96ee7267396b8fc9ccb5d5897056728f183d94853e51dc4d32a3e161e958c63af36c', '2012-11-26 12:09:01', 'prolsobrado@gmail.com', 1),
('dldacal', 'd597188842e94faf54dd6b46f0dfe09cb9868be10c6963d8ea564096b4193ee8cc23ca7985b954242910632bc5a37f28ebcc37ed6df9bd00eee8cb9551c06165', '2012-12-13 11:09:41', 'david_ld92@hotmail.com', 0),
('amlopez', 'b4ff2f0dd758dde655294685d64e0e81c39fae7792a89c8a59373774078cd41d5d6f3f96ab8b3f9418121274708ac760fd878f4d299294d6ad1b3b3c68167d7a', '2012-12-03 18:10:11', 'anamiguezlopez@gmail.com', 0),
('zoran', '3627909a29c31381a071ec27f7c9ca97726182aed29a7ddd2e54353322cfb30abb9e3a6df2ac2c20fe23436311d678564d0c8d305930575f60e2d3d048184d79', '2012-12-04 17:03:09', 'blancynegro@hotmail.com', 0),
('soiber', '8c34da988427e0b6bb05fb715567fbed32036f20bc1fb66d53298e575b1d284d3a9adab6754a068e12e0d5ede4790d8f9a7d74e246d13337240b2c6121ff962c', '2012-12-09 17:06:56', 'soiber@gmail.com', 0),
('David', '6d8c0965eebc3987159354716667ee8a4604328879350ad850ab1fd0a16e24650d5a820ad6c8621d2c52411d4fe227df07ae5f6870c63a0e8848a3a2a506d1b1', '2012-12-09 21:08:59', 'drakon.dgs@hotmail.com', 0),
('luisCopo', '15440cf073f0668e31c1bcdf91af3ed69e06d6a683cc6fe6952c33c9ad738b142e3e080ba6752e446624eacbc7f6a91fbb3e3c21698e5b021da7d23ae99b3415', '2012-12-10 09:57:19', 'luiscopoarias@gmail.com', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `valoracion`
--

CREATE TABLE IF NOT EXISTS `valoracion` (
  `nombreUsuario` varchar(50) NOT NULL,
  `idProfesor` int(2) NOT NULL,
  `valoracion` float NOT NULL,
  PRIMARY KEY (`nombreUsuario`,`idProfesor`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
