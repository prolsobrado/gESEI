<?php
include('bd.php');

if ($_SESSION['mensaje']) {
	$mensaje = $_SESSION['mensaje'];
	unset($_SESSION['mensaje']);
}

if ((!$persona) && (strpos($_SERVER['REQUEST_URI'],'index')==0)) {
	header('Location: index.php');
}
?>
<!DOCTYPE html>
<html lang="es">
	<head>
		<title>gESEI: <?php echo $titulo; ?></title>
		<link rel="stylesheet" type="text/css" href="css/reset.css">
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<meta charset="windows-1252">
		<script type="text/javascript">
			function cambiarVisibilidad(id) {
				var elemento = document.getElementById(id);
				if (elemento.className == "visible") {
					elemento.className = "invisible";
				}
				else {
					elemento.className = "visible";
				}
			}
		</script>
	</head>
	<body>
		<div id="princ">
			<header>
				<span id="enlaceTitulo">gESEI</span>
			</header>
			
			<div id="contenedor">
				
				<div class="menu">
					<div class="campo">
						<ul>
							<li><a href="firmas.php">Control de Asistencia (Alumnos y Profesores)</a></li>
							<li><a href="gestionDatos.php">Gesti�n de Datos (Cualquiera)</a></li>
							<li><a href="gestionIncidencias.php">Gesti�n de Incidencias (Director)</a></li>
						</ul>
					</div>
					<div class="campo">
						<a href="http://esei.uvigo.es/" class="tam-her" target="_blank"><img class="tam-her" src="http://esei.uvigo.es/fileadmin/templates/img/nombreESEI.png" alt=""></a>
					</div>
					<?php
					
					if ($persona) {
					?>
						<div class="campo">
							<?php
							if ($test == 'true') {
								echo '<form class="form-log" action="'.$_SERVER['PHP_SELF'].'" method="post">';
								echo 'Modo Test - Variables<br /><br />';
								echo 'Persona: <input type="text" value="'.$persona.'" readonly="readonly" /><br />';
								echo 'Tipo Persona: <input type="text" value="'.$tipoPersona.'" readonly="readonly" /><br />';
								echo 'D�a: <input type="text" name="dia" value="'.$dia.'" /><br />';
								echo 'Date: <input type="text" name="date" value="'.$date.'" /><br />';
								echo 'Time: <input type="text" name="time" value="'.$time.'" /><br />';
								echo '<input type="submit" value="Cambiar" />';
								echo '</form>';
								?>
								<div class="boton_salir">
									<a href="<?php echo $_SERVER['PHP_SELF']; ?>?test=false">Modo Real</a>
								</div>
								<?php
							}
							else {
								echo '<form class="form-log">';
								echo 'Modo Real - Variables<br /><br />';
								echo 'Persona: <input type="text" value="'.$persona.'" readonly="readonly" /><br />';
								echo 'Tipo Persona: <input type="text" value="'.$tipoPersona.'" readonly="readonly" /><br />';
								echo 'D�a: <input type="text" value="'.$dia.'" readonly="readonly" /><br />';
								echo 'Date: <input type="text" value="'.$date.'" readonly="readonly" /><br />';
								echo 'Time: <input type="text" value="'.$time.'" readonly="readonly" /><br />';
								echo '</form>';
								?>
								<div class="boton_salir">
									<a href="<?php echo $_SERVER['PHP_SELF']; ?>?test=true">Modo Test</a>
								</div>
								<?php
							}
							?>
							<div class="boton_salir">
								<a href="index.php?salir=true">Salir</a>
							</div>
						</div>
					<?php
					}
					else {
					?>
						<div class="campo">
							Usuarios (Click para iniciar sesi�n)<br /><br />
							<ul>Alumnos:
							<li><a href="index.php?entrar=true&username=47048169J&password=47048169J">- 47048169J / 47048169J</a></li>
							<li><a href="index.php?entrar=true&username=44464087G&password=44464087G">- 44464087G / 44464087G</a></li>
							</ul>
							<br />
							<ul>Profesores:
							<li><a href="index.php?entrar=true&username=12345678A&password=12345678A">- 12345678A / 12345678A</a></li>
							<li><a href="index.php?entrar=true&username=87654321Z&password=87654321Z">- 87654321Z / 87654321Z</a></li>
							</ul>
							<br />
							<ul>Becario:
							<li><a href="index.php?entrar=true&username=88888888Y&password=88888888Y">- 88888888Y / 88888888Y</a></li>
							</ul>
							<br />
							<ul>Director:
							<li><a href="index.php?entrar=true&username=11111111B&password=11111111B">- 11111111B / 11111111B</a></li>
							</ul>
						</div>
					<?php
					}
					?>
				</div>
				
				<div class="contenido">
					<?php
					if ($mensaje) {
						?>
						<script type="text/javascript">
							window.load = setTimeout("cambiarVisibilidad('mensaje')", 3000);
						</script>
						<div id="mensaje" class="visible">
							<?php echo $mensaje; ?>
						</div>
						<?php
					}
					?>
					<h1><?php echo $titulo; ?></h1>