<?php
$conexion = mysql_connect('localhost', 'userBD', 'passBD');
mysql_select_db('nombreBD', $conexion);
mysql_query("SET NAMES 'latin'", $conexion);
putenv('TZ=Europe/Madrid');

session_start();
$persona = $_SESSION['persona'];
$tipoPersona = $_SESSION['tipoPersona'];

if (!$_SESSION['test']) {
	$_SESSION['test'] = 'true';
}
if ($_REQUEST['test']) {
	$_SESSION['test'] = $_REQUEST['test'];
	$_SESSION['mensaje'] = 'Se ha cambiado el modo de funcionamiento';
	header('Location: '.$_SERVER['PHP_SELF'].'');
	die();
}
$test = $_SESSION['test'];
if ($test == 'true') {
	if ((!$_SESSION['dia']) && (!$_SESSION['date']) && (!$_SESSION['time'])) {
		$_SESSION['dia'] = 'Lunes';
		$_SESSION['date'] = '2012-12-03';
		$_SESSION['time'] = '16:30:00';
	}
	if (($_REQUEST['dia']) && ($_REQUEST['date']) && ($_REQUEST['time'])) {
		$_SESSION['dia'] = $_REQUEST['dia'];
		$_SESSION['date'] = $_REQUEST['date'];
		$_SESSION['time'] = $_REQUEST['time'];
		$_SESSION['mensaje'] = 'Se han cambiado las variables';
		header('Location: '.$_SERVER['PHP_SELF'].'');
		die();
	}
	$dia = $_SESSION['dia'];
	$date = $_SESSION['date'];
	$time = $_SESSION['time'];
}
else {
	$day = date('D');
	switch ($day) {
		case 'Mon':
			$dia = 'Lunes';
			break;
		case 'Tue':
			$dia = 'Martes';
			break;
		case 'Wed':
			$dia = 'Mi�rcoles';
			break;
		case 'Thu':
			$dia = 'Jueves';
			break;
		case 'Fri':
			$dia = 'Viernes';
			break;
		case 'Sat':
			$dia = 'S�bado';
			break;
		case 'Sun':
			$dia = 'Domingo';
			break;
	}
	$date = date('Y-m-d');
	$time = date('H:i:s');
}
$timeReplaced = preg_replace('/:/', '', $time);
$dateTime = $date.' '.$time;
?>