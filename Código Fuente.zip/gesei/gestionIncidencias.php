<?php
include('bd.php');

if ($_REQUEST['incidencia']) {
	$idIncidencia = $_REQUEST['incidencia'];
	$incidencia = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_incidencia WHERE id = '$idIncidencia'", $conexion));
	$propietario = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_persona WHERE dni IN(SELECT idPersona FROM abp_incidencia WHERE id = '$idIncidencia')", $conexion));
	$nivelIncidencia = $incidencia['nivel'];
	
	$headers = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
	$headers .= "From: gESEI <gesei@estafaviejas.com>\r\n";
	$headers .= "Reply-To: no-reply@estafaviejas.com\r\n";
	$destinatario = $propietario['email'];
	switch ($nivelIncidencia) {
		case 0:
			$asunto = "gESEI - Incidencia, primer aviso";
			$cuerpo = '
			<html>
				<head>
					<title>Notificaci�n de gESEI</title>
				</head>
				<body>
					<h1>Tienes una incidencia en el sistema (1� Aviso)</h1>
					<p>
						<b>Esto puede ser debido a que no has asistido a una asignaci�n que ten�as en el sistema.</b>
						Por favor, ponte en contacto con tu superior para arreglar esto.
					</p>
				</body>
			</html>
			';
			$nuevoNivel = 1;
			break;
		case 1:
			$asunto = "gESEI - Incidencia, segundo aviso";
			$cuerpo = '
			<html>
				<head>
					<title>Notificaci�n de gESEI</title>
				</head>
				<body>
					<h1>Tienes una incidencia en el sistema (2� Aviso)</h1>
					<p>
						<b>Esto puede ser debido a que no has asistido a una asignaci�n que ten�as en el sistema.</b>
						Por favor, te rogamos encarecidamente que te pongas en contacto con tu superior para arreglar esto.
					</p>
				</body>
			</html>
			';
			$nuevoNivel = 2;
			break;
		case 2:
			$asunto = "gESEI - Incidencia, tercer aviso";
			$cuerpo = '
			<html>
				<head>
					<title>Notificaci�n de gESEI</title>
				</head>
				<body>
					<h1>Tienes una incidencia en el sistema (3� Aviso)</h1>
					<p>
						<b>Si no arreglas esta situaci�n, procederemos a sancionarte.</b>
						Por favor, te rogamos encarecidamente que te pongas en contacto con tu superior para arreglar esto.
					</p>
				</body>
			</html>
			';
			$nuevoNivel = 3;
			break;
		case 3:
			$asunto = "gESEI - Sanci�n";
			$cuerpo = '
			<html>
				<head>
					<title>Notificaci�n de gESEI</title>
				</head>
				<body>
					<h1>Has sido sancionado</h1>
					<p>
						<b>Nos lamenta decirte que debido a tu falta de respuesta, tenemos que llevar a cabo una sanci�n administrativa.</b>
						El director de tu centro ya ha comenzado los tr�mites para realizarla.
					</p>
				</body>
			</html>
			';
			$nuevoNivel = 3;
			break;
	}
	
	$retornoSQL = mysql_query("UPDATE abp_incidencia SET nivel='$nuevoNivel' WHERE id='$idIncidencia'", $conexion);
	if ($retornoSQL) {
		$retornoMail = mail($destinatario, $asunto, $cuerpo, $headers);
		if ($retornoMail) {
			$_SESSION['mensaje'] = 'Se ha enviado el correo';
		}
		else {
			$_SESSION['mensaje'] = 'No se ha enviado el correo por un error en el servidor de correo';
		}
	}
	else {
		$_SESSION['mensaje'] = 'No se ha enviado el correo por un error en la BD';
	}
	
	header('Location: gestionIncidencias.php');
	die();
}

$titulo = 'Gesti�n de Incidencias';
include('cabecera.php');

switch ($tipoPersona) {
	case 'Director':
		$sql = mysql_query("SELECT * FROM abp_incidencia", $conexion);
		if (mysql_num_rows($sql) == 0) {
			echo '<p>No existen incidencias en el sistema</p>';
		}
		else {
			?>
			<table>
				<tbody>
					<tr>
						<th>ID</th>
						<th>ID Persona</th>
						<th>Nombre Persona</th>
						<th>Nombre Tarea</th>
						<th>Recurso Tarea</th>
						<th>Hora Proram.</th>
						<th>Fecha</th>
						<th>Acci�n</th>
					</tr>
			<?php
			$alt = false;
			while ($recorrer = mysql_fetch_assoc($sql)) {
				$dniPersona = $recorrer['idPersona'];
				$sqlPersona = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_persona WHERE dni = '$dniPersona'", $conexion));
				$idTarea = $recorrer['idTarea'];
				$sqlTarea = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_tarea WHERE id = '$idTarea'", $conexion));
				$idRecurso = $sqlTarea['idRecurso'];
				$sqlRecurso = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_recurso WHERE id = '$idRecurso'", $conexion));
				$tipoTarea = $recorrer['tipoTarea'];
				$idAsignacion = $recorrer['idAsignacion'];
				$nivel = $recorrer['nivel'];

				if ($alt) { echo '<tr class="alt">'; $alt = false; } else { echo '<tr>'; $alt = true; }
					echo '<td>'.$recorrer['id'].'</td>';
					echo '<td>'.$dniPersona.'</td>';
					echo '<td>'.$sqlPersona['nombre'].' '.$sqlPersona['apellidos'].'</td>';
					switch ($tipoTarea) {
						case 1: //AAC
							$sqlTipo = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_asignatura WHERE id IN (SELECT idAsignatura FROM abp_clase WHERE idTarea = '$idTarea')", $conexion));
							$echoTipo = $sqlTipo['nombre'];
							break;
						case 2: //ABPT
							break;
						case 3: //APC
							$sqlTipo = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_asignatura WHERE id IN (SELECT idAsignatura FROM abp_clase WHERE idTarea = '$idTarea')", $conexion));
							$echoTipo = $sqlTipo['nombre'];
							break;
						case 4: //APT
							$echoTipo = 'Tutor�a';
							break;
					}
					echo '<td>'.$echoTipo.'</td>';
					echo '<td>'.$sqlRecurso['nombre'].' ('.$sqlRecurso['planta'].'� Planta)</td>';
					echo '<td>'.$sqlTarea['horaInicio'].'</td>';
					echo '<td>'.$recorrer['fecha'].'</td>';
					switch ($nivel) {
						case 0:
							echo '<td><a href="gestionIncidencias.php?incidencia='.$recorrer['id'].'">Enviar primer aviso</a></td>';
							break;
						case 1:
							echo '<td><a href="gestionIncidencias.php?incidencia='.$recorrer['id'].'">Enviar segundo aviso</a></td>';
							break;
						case 2:
							echo '<td><a href="gestionIncidencias.php?incidencia='.$recorrer['id'].'">Enviar tercer aviso</a></td>';
							break;
						case 3:
							echo '<td><a href="gestionIncidencias.php?incidencia='.$recorrer['id'].'">Sancionar</a></td>';
							break;
					}
				echo '</tr>';
			}
			?>
				</tbody>
			</table>
			<?php
		}
		break;
	default:
		echo '<p>No tienes permisos para esta secci�n</p>';
		break;
}

include('pie.php');
?>