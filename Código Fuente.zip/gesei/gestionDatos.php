<?php
include('bd.php');

if ($_REQUEST['guardar']) {
	$contrasena = $_REQUEST['contrasena'];
	$nombre = $_REQUEST['nombre'];
	$apellidos = $_REQUEST['apellidos'];
	$email = $_REQUEST['email'];
	$telefono = $_REQUEST['telefono'];
	$direccion = $_REQUEST['direccion'];
	mysql_query("UPDATE abp_persona SET contrasena='$contrasena', nombre='$nombre', apellidos='$apellidos', email='$email', telefono='$telefono', direccion='$direccion' WHERE dni = '$persona'", $conexion);
	$_SESSION['mensaje'] = 'Se han modificado los datos';
	header('Location: gestionDatos.php');
	die();
}

$titulo = 'Gesti�n de Datos';
include('cabecera.php');

$datos = mysql_fetch_assoc(mysql_query("SELECT * FROM abp_persona WHERE dni = '$persona'", $conexion));
?>
<form class="form-log" action="gestionDatos.php" method="post">
	Usuario (DNI): <input type="text" name="dni" value="<?php echo $datos['dni']; ?>" readonly="readonly" /> <br />
	Contrase�a: <input type="password" name="contrasena" value="<?php echo $datos['contrasena']; ?>" /> <br />
	Nombre: <input type="text" name="nombre" value="<?php echo $datos['nombre']; ?>" /> <br />
	Apellidos: <input type="text" name="apellidos" value="<?php echo $datos['apellidos']; ?>" /> <br />
	Email: <input type="text" name="email" value="<?php echo $datos['email']; ?>" /> <br />
	Telefono: <input type="text" name="telefono" value="<?php echo $datos['telefono']; ?>" /> <br />
	Direccion: <input type="text" name="direccion" value="<?php echo $datos['direccion']; ?>" /> <br />
	<input type="submit" name="guardar" value="Guardar" />
</form>
<?php

include('pie.php');
?>