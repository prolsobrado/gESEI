				</div>
				
				<div class="clear"></div>
			</div>
			
			<footer>
				Copyright
			</footer>
		</div>
	</body>
</html>